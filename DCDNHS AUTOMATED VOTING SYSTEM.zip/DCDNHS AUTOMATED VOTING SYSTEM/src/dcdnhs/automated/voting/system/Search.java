
package dcdnhs.automated.voting.system;
import java.sql.ResultSet;
import java.sql.Statement;
import com.mysql.jdbc.Connection;
import java.sql.PreparedStatement;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Search {
    
    
    public static Statement st;
     public static Connection con;
      public static PreparedStatement getdata;
     static{

        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = (Connection) DriverManager.getConnection("jdbc:mysql://localhost/Moonstone","root","");
            st = con.createStatement();
            getdata =con.prepareStatement("Select * from voter where Name like ?");
        } catch (SQLException ex) {
            Logger.getLogger(Search.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Search.class.getName()).log(Level.SEVERE, null, ex);
        }
     
}
       public static ResultSet getdata(String Name) throws SQLException{
           getdata.setString(1, "%"+Name+"%");
        return getdata.executeQuery();
           
       }
}


