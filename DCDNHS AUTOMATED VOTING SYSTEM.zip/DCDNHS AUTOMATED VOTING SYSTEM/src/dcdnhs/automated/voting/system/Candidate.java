/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package dcdnhs.automated.voting.system;

import java.awt.Image;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;
import net.proteanit.sql.DbUtils;

/**
 *
 * @author User
 */
public class Candidate extends javax.swing.JFrame {

    private String vgender;

    /**
     * Creates new form Candidate
     */
    public Candidate() {
        initComponents();
        DisplayCand();
           FetchPhoto();
    }

   
     Connection con= null;
PreparedStatement pst= null;
ResultSet rs = null;
Statement st = null;

String imgpath=null;
 
 private ImageIcon ResizePhoto(String ImagePath, byte[] pic)
 {
 
 
     ImageIcon MyImage = null;
     
     if(ImagePath != null)
     {
 
     MyImage = new ImageIcon(ImagePath);
     } else
     
     {
         MyImage =  new ImageIcon(pic);
         }
 Image img = MyImage.getImage();
 Image newimg= img.getScaledInstance(candidatephoto.getWidth(), candidatephoto.getHeight(),Image.SCALE_SMOOTH);
 ImageIcon image=new ImageIcon(newimg);
         return image;
 }private void FetchPhoto(){
    
    String query ="Select Photo from candidate where cID="+key;
    Statement st;
    ResultSet rs;
    try{
     con=DriverManager.getConnection("jdbc:mysql://localhost/Moonstone","root","");
    st=con.createStatement();
    rs=st.executeQuery(query);
    if(rs.next()){
    
    candidatephoto.setIcon(ResizePhoto(null,rs.getBytes("Photo")));
    
    }
    
    }catch (Exception e){
    
    
    }
    }
    
    
    
    
    int key = -1;
    private void DisplayCand(){
    
    try{
     con=DriverManager.getConnection("jdbc:mysql://localhost/Moonstone","root","");
     st=con.createStatement();
     rs=st.executeQuery("Select * from candidate");
   candidatetable.setModel(DbUtils.resultSetToTableModel(rs));
     
    }catch(Exception e){
    
    
    }
    }
 int cID;
    Statement st1 = null;
    ResultSet rs1= null;
  private void CandCount(){
        
try{
    
    st1 = con.createStatement();
    rs1 =  st1.executeQuery("Select Max(cID) From candidate");
    rs1.next();
    cID = rs1.getInt(1)+ 1;
    }catch(Exception ex){
            
            }


}
           
       
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        kGradientPanel1 = new com.k33ptoo.components.KGradientPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        candidatetable = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        candidatephoto = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        rbFemale = new javax.swing.JRadioButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        Name = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        Birthdate = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        yearlevel = new javax.swing.JTextField();
        rbMale = new javax.swing.JRadioButton();
        cbPosition = new javax.swing.JComboBox<>();
        jLabel13 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        kButton1 = new com.k33ptoo.components.KButton();
        kButton2 = new com.k33ptoo.components.KButton();
        kButton3 = new com.k33ptoo.components.KButton();
        kButton4 = new com.k33ptoo.components.KButton();
        kButton7 = new com.k33ptoo.components.KButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        kGradientPanel1.setkEndColor(new java.awt.Color(0, 255, 255));
        kGradientPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jScrollPane1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        candidatetable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        candidatetable.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                candidatetableAncestorAdded(evt);
            }
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        candidatetable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                candidatetableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(candidatetable);

        kGradientPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 90, 830, 510));

        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        candidatephoto.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        candidatephoto.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        candidatephoto.setText("Photo");

        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jButton1.setText("Select Image");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        rbFemale.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        rbFemale.setText("Female");
        rbFemale.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbFemaleActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel2.setText("BirthDate :");

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel6.setText("Year&Section :");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel3.setText("Gender :");

        Name.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setText("Fullname :");

        Birthdate.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel4.setText("Position :");

        yearlevel.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N

        rbMale.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        rbMale.setText("Male");
        rbMale.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbMaleActionPerformed(evt);
            }
        });

        cbPosition.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        cbPosition.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "President", "Vice President", "Secretary", "Treasurer", "P.I.O", "Auditor", "Protocol Officer" }));
        cbPosition.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbPositionActionPerformed(evt);
            }
        });

        jLabel13.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel13.setText("CANIDATES REGISTRATION FORM");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(rbMale, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(rbFemale, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(yearlevel, javax.swing.GroupLayout.PREFERRED_SIZE, 270, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(cbPosition, javax.swing.GroupLayout.PREFERRED_SIZE, 222, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(34, 34, 34)
                                .addComponent(Birthdate, javax.swing.GroupLayout.PREFERRED_SIZE, 270, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(Name, javax.swing.GroupLayout.PREFERRED_SIZE, 270, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(26, 26, 26))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(68, 68, 68)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jLabel13, javax.swing.GroupLayout.DEFAULT_SIZE, 305, Short.MAX_VALUE)
                                    .addComponent(jSeparator1)))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(150, 150, 150)
                                .addComponent(candidatephoto, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(129, 129, 129)
                                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(jLabel13)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(candidatephoto, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton1)
                .addGap(24, 24, 24)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Name, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Birthdate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(rbFemale)
                    .addComponent(rbMale)
                    .addComponent(jLabel3))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(cbPosition, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(yearlevel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(76, Short.MAX_VALUE))
        );

        kGradientPanel1.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 90, -1, 570));

        kButton1.setText("Update");
        kButton1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        kButton1.setkEndColor(new java.awt.Color(102, 102, 255));
        kButton1.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        kButton1.setkHoverStartColor(new java.awt.Color(51, 51, 255));
        kButton1.setkPressedColor(new java.awt.Color(51, 102, 255));
        kButton1.setkSelectedColor(new java.awt.Color(0, 51, 255));
        kButton1.setkStartColor(new java.awt.Color(51, 51, 255));
        kButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                kButton1ActionPerformed(evt);
            }
        });
        kGradientPanel1.add(kButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 610, 170, -1));

        kButton2.setText("Reset");
        kButton2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        kButton2.setkEndColor(new java.awt.Color(255, 204, 0));
        kButton2.setkHoverEndColor(new java.awt.Color(255, 255, 0));
        kButton2.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        kButton2.setkHoverStartColor(new java.awt.Color(255, 204, 51));
        kButton2.setkPressedColor(new java.awt.Color(204, 153, 0));
        kButton2.setkSelectedColor(new java.awt.Color(255, 204, 0));
        kButton2.setkStartColor(new java.awt.Color(255, 204, 0));
        kButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                kButton2ActionPerformed(evt);
            }
        });
        kGradientPanel1.add(kButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(920, 610, 170, -1));

        kButton3.setText("Delete");
        kButton3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        kButton3.setkEndColor(new java.awt.Color(255, 0, 0));
        kButton3.setkHoverEndColor(new java.awt.Color(255, 0, 51));
        kButton3.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        kButton3.setkHoverStartColor(new java.awt.Color(255, 51, 51));
        kButton3.setkPressedColor(new java.awt.Color(255, 51, 51));
        kButton3.setkSelectedColor(new java.awt.Color(255, 0, 0));
        kButton3.setkStartColor(new java.awt.Color(255, 0, 0));
        kButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                kButton3ActionPerformed(evt);
            }
        });
        kGradientPanel1.add(kButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(1120, 610, 170, -1));

        kButton4.setText("Add");
        kButton4.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        kButton4.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        kButton4.setkHoverStartColor(new java.awt.Color(102, 255, 0));
        kButton4.setkPressedColor(new java.awt.Color(102, 255, 0));
        kButton4.setkSelectedColor(new java.awt.Color(51, 204, 0));
        kButton4.setkStartColor(new java.awt.Color(51, 204, 0));
        kButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                kButton4ActionPerformed(evt);
            }
        });
        kGradientPanel1.add(kButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 610, 170, -1));

        kButton7.setIcon(new javax.swing.ImageIcon("C:\\Users\\User\\Desktop\\icons for java\\close32.png")); // NOI18N
        kButton7.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        kButton7.setkBorderRadius(30);
        kButton7.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        kButton7.setkHoverStartColor(new java.awt.Color(255, 51, 51));
        kButton7.setkPressedColor(new java.awt.Color(255, 51, 51));
        kButton7.setkSelectedColor(new java.awt.Color(255, 51, 51));
        kButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                kButton7ActionPerformed(evt);
            }
        });
        kGradientPanel1.add(kButton7, new org.netbeans.lib.awtextra.AbsoluteConstraints(1310, 10, 40, 60));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(kGradientPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 1390, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(kGradientPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 771, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void cbPositionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbPositionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbPositionActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        
        
         JFileChooser chooser = new JFileChooser();
        chooser.setCurrentDirectory(new File (System.getProperty("user.home")));
        FileNameExtensionFilter filter= new FileNameExtensionFilter("*.Images","jpg,","gif","png");
        chooser.addChoosableFileFilter(filter);
        int result=chooser.showSaveDialog(null);
        if(result==JFileChooser.APPROVE_OPTION){

            File selectedFile = chooser.getSelectedFile();
            String path = selectedFile.getAbsolutePath();
            candidatephoto.setIcon(ResizePhoto(path,null));
            imgpath = path;
        }
    }//GEN-LAST:event_jButton1ActionPerformed
private JFrame frame;
    private void kButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_kButton7ActionPerformed
        // TODO add your handling code here:
        frame = new JFrame("Exit");
        if (JOptionPane.showConfirmDialog(this," Do you want to Exit? " ,"DCDNHS Automated Voting System",
            JOptionPane.YES_NO_OPTION) ==JOptionPane.YES_NO_OPTION)
    {
        new Admin_Dashboard().setVisible(true);
         this.dispose();;
        }
    }//GEN-LAST:event_kButton7ActionPerformed

    private void kButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_kButton4ActionPerformed
        // TODO add your handling code here:
        
          if (Birthdate.getText().isEmpty() || Name.getText().isEmpty() ){
            JOptionPane.showMessageDialog(this, "Missing Information");

        }else{
            try {
                CandCount();
                con=DriverManager.getConnection("jdbc:mysql://localhost/Moonstone","root","");
            pst=con.prepareStatement("Insert into candidate values(?,?,?,?,?,?,?)");
                InputStream img= new FileInputStream(imgpath);
                pst.setInt(1, cID);
                pst.setString(2, Name.getText());
                pst.setString(3, Birthdate.getText());
                pst.setString(4, vgender);
                pst.setString(5, yearlevel.getText());
                pst.setString(6, cbPosition.getSelectedItem().toString());
                pst.setBlob(7, img);

                int row=pst.executeUpdate();
                JOptionPane.showMessageDialog(this, "Candidate Registered");
                con.close();
                DisplayCand();

            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, ex);
            }

        }
    }//GEN-LAST:event_kButton4ActionPerformed

    private void rbMaleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbMaleActionPerformed
        // TODO add your handling code here:
         vgender = "Male";
        if(rbMale.isSelected()){
            rbFemale.setSelected(false);
        }
    }//GEN-LAST:event_rbMaleActionPerformed

    private void rbFemaleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbFemaleActionPerformed
        // TODO add your handling code here:
           vgender = "Female";
        if(rbFemale.isSelected()){
            rbMale.setSelected(false);
        }
    }//GEN-LAST:event_rbFemaleActionPerformed

    private void candidatetableAncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_candidatetableAncestorAdded
        // TODO add your handling code here:
       
    }//GEN-LAST:event_candidatetableAncestorAdded

    private void candidatetableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_candidatetableMouseClicked
        // TODO add your handling code here:
          DefaultTableModel model= (DefaultTableModel) candidatetable.getModel();
        int MyIndex = candidatetable.getSelectedRow();
        key = Integer.valueOf(model.getValueAt(MyIndex, 0).toString());
        Name.setText(model.getValueAt(MyIndex, 1).toString());
        Birthdate.setText(model.getValueAt(MyIndex, 2).toString());
         String Gender = model.getValueAt(MyIndex,3).toString();
      
       if(Gender.equals("Male")){
          rbMale.setSelected(true);
          rbFemale.setSelected(false);
       
           
       }else{
            rbFemale.setSelected(true);
            rbMale.setSelected(false);
         
       }
        yearlevel.setText(model.getValueAt(MyIndex, 4).toString());
        cbPosition.setSelectedItem(model.getValueAt(MyIndex, 5).toString());
        FetchPhoto();
    }//GEN-LAST:event_candidatetableMouseClicked

    private void kButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_kButton1ActionPerformed
        // TODO add your handling code here:
        
         if(key== -1 || Name.getText().toString().isEmpty() || Birthdate.getText().toString().isEmpty() ||
           yearlevel.getText().toString().isEmpty() ){

        }else if (imgpath != null)
        {
            try{
                InputStream  img= new FileInputStream(imgpath);
                con=DriverManager.getConnection("jdbc:mysql://localhost/Moonstone","root","");
                pst =con.prepareStatement( "Update candidate set Name=?,Birthdate = ? ,Gender = ?, YearlevelSection = ? , Position=?, Photo=?  where cID=?");
             
                pst.setString (1,Name.getText());
                pst.setString(2,Birthdate.getText());
                String selection;

            if(rbMale.isSelected()){
                selection = "Male";
            }
            else{
                selection = "Female";
            }
            
                pst.setString(3,selection);
                pst.setString (4,yearlevel.getText());
                pst.setString (5,cbPosition.getSelectedItem().toString());
                pst.setBlob (6,img);
                pst.setInt (7,key);
                if(pst.executeUpdate() == 1) {

                    JOptionPane.showMessageDialog(this, "Candidate Updated Succesfully");
                    DisplayCand();
                }else{
                    JOptionPane.showMessageDialog(this, "Missing Information");
                }

            }catch(Exception e){
                JOptionPane.showMessageDialog(this, e);
            }

        }else {
            JOptionPane.showMessageDialog(this, "Select Photo To be Updated");
            candidatephoto.setIcon(null);
            candidatephoto.setText("");
        }
        
    }//GEN-LAST:event_kButton1ActionPerformed
public void  Rerun(){
    
    new Candidate().setVisible(true);
    setVisible(false);
    
    }
    private void kButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_kButton2ActionPerformed
        // TODO add your handling code here:
        Rerun();
    }//GEN-LAST:event_kButton2ActionPerformed

    private void kButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_kButton3ActionPerformed
        // TODO add your handling code here:
          if(key== -1){
            JOptionPane.showMessageDialog(this, "Select The Candidate To Be  Deleted");
        }else
        {
            try{

                con=DriverManager.getConnection("jdbc:mysql://localhost/Moonstone","root","");
                String Query = "Delete From candidate where cID = "+key;
                Statement del = con.createStatement();
                del.executeUpdate(Query);
                JOptionPane.showMessageDialog(this, "candidate Deleted Succesfully");
                DisplayCand();
            }catch(Exception e){
                JOptionPane.showMessageDialog(this, e);
            }

        }
    }//GEN-LAST:event_kButton3ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Candidate.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Candidate.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Candidate.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Candidate.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Candidate().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField Birthdate;
    private javax.swing.JTextField Name;
    private javax.swing.JLabel candidatephoto;
    private javax.swing.JTable candidatetable;
    private javax.swing.JComboBox<String> cbPosition;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private com.k33ptoo.components.KButton kButton1;
    private com.k33ptoo.components.KButton kButton2;
    private com.k33ptoo.components.KButton kButton3;
    private com.k33ptoo.components.KButton kButton4;
    private com.k33ptoo.components.KButton kButton7;
    private com.k33ptoo.components.KGradientPanel kGradientPanel1;
    private javax.swing.JRadioButton rbFemale;
    private javax.swing.JRadioButton rbMale;
    private javax.swing.JTextField yearlevel;
    // End of variables declaration//GEN-END:variables
}
