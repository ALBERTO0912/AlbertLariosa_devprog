/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package dcdnhs.automated.voting.system;

import java.awt.print.PrinterException;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.TableModel;
import javax.swing.RowFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import net.proteanit.sql.DbUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFChartSheet;
import textfield.SearchOption;

public class Voter extends javax.swing.JFrame {

    private String vgender;

   DefaultTableModel model;
    private JTable mytable;
    public Voter() {
        initComponents();
       DisplayVoters();
        Voter();
       
    }

    public void search1(String Str){
    
        model=(DefaultTableModel) VoterTable.getModel();
        TableRowSorter<DefaultTableModel> trs = new TableRowSorter<>(model);
        VoterTable.setRowSorter(trs);
       trs.setRowFilter(RowFilter.regexFilter(Str));
       
       
    }
   
   
   Connection con= null;
PreparedStatement pst= null;
ResultSet rs = null;
Statement st = null;

private void DisplayVoters(){
    
    try{
     con=DriverManager.getConnection("jdbc:mysql://localhost/Moonstone","root","");
     pst=con.prepareStatement("Select * from voter");
   ResultSet  rs=pst.executeQuery();
 votertable.setModel(DbUtils.resultSetToTableModel(rs));
     while(rs.next()){
     
         String ID= rs.getString("vID");
          String Name= rs.getString("Name");
           String BD= rs.getString("Birthdate");
            String G= rs.getString("Gender");
             String ys= rs.getString("YearSection");
              String u= rs.getString("Username");
               String p= rs.getString("Password");
               
               Object[] obj ={ID,Name,BD,G,ys,u,p};
               
               model=(DefaultTableModel) votertable.getModel();
               model.addRow(obj);
     }
    }catch(Exception e){
  
    }
    }
   int ID;
    Statement st1 = null;
    ResultSet rs1= null;
    
   private void VoteCount(){
        
try{
    
    st1 = con.createStatement();
    rs1 =  st1.executeQuery("Select Max(vID) From voter");
    rs1.next();
    ID = rs1.getInt(1)+ 1;
    }catch(Exception ex){
            
            }


}
 
  public void Voter(){
  
        try {
            pst = con.prepareStatement("Select Count(*) AS VoterCount From voter ");
            ResultSet rs = pst.executeQuery();
            while (rs.next()){
            int count = rs.getInt("VoterCount");
            
            num.setText(String.valueOf(count ));
            
            }
            
            
        } catch (SQLException ex) {
            Logger.getLogger(Voter.class.getName()).log(Level.SEVERE, null, ex);
        }
  
  }
    
   int key =  -1;
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jInternalFrame1 = new javax.swing.JInternalFrame();
        jPanel1 = new javax.swing.JPanel();
        Age = new javax.swing.JTextField();
        kButton1 = new com.k33ptoo.components.KButton();
        kButton3 = new com.k33ptoo.components.KButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        VoterTable = new javax.swing.JTable();
        jLabel6 = new javax.swing.JLabel();
        kButton5 = new com.k33ptoo.components.KButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        Name = new javax.swing.JTextField();
        vcbGender = new javax.swing.JComboBox<>();
        Pass = new javax.swing.JTextField();
        Input = new com.k33ptoo.components.KButton();
        jLabel7 = new javax.swing.JLabel();
        Delete = new com.k33ptoo.components.KButton();
        jLabel3 = new javax.swing.JLabel();
        Section = new javax.swing.JTextField();
        Print = new com.k33ptoo.components.KButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtReciept = new javax.swing.JTextArea();
        kButton6 = new com.k33ptoo.components.KButton();
        VoterID = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        kGradientPanel1 = new com.k33ptoo.components.KGradientPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        Password = new javax.swing.JPasswordField();
        section = new javax.swing.JTextField();
        rbMale = new javax.swing.JRadioButton();
        Birthdate = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        rbFemale = new javax.swing.JRadioButton();
        jLabel12 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        Username = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        btnupdate = new com.k33ptoo.components.KButton();
        btnsave = new com.k33ptoo.components.KButton();
        btndelete = new com.k33ptoo.components.KButton();
        btnprint = new com.k33ptoo.components.KButton();
        btndelete1 = new com.k33ptoo.components.KButton();
        btnimport1 = new com.k33ptoo.components.KButton();
        cbShow = new javax.swing.JCheckBox();
        jLabel16 = new javax.swing.JLabel();
        name = new javax.swing.JTextField();
        jSeparator2 = new javax.swing.JSeparator();
        jScrollPane3 = new javax.swing.JScrollPane();
        votertable = new javax.swing.JTable();
        jScrollPane4 = new javax.swing.JScrollPane();
        Receipt = new javax.swing.JTextArea();
        kButton7 = new com.k33ptoo.components.KButton();
        jPanel4 = new javax.swing.JPanel();
        jLabel15 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        name1 = new javax.swing.JTextField();
        num = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jSeparator3 = new javax.swing.JSeparator();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jInternalFrame1.setPreferredSize(new java.awt.Dimension(1130, 760));

        jPanel1.setBackground(new java.awt.Color(0, 153, 153));
        jPanel1.setPreferredSize(new java.awt.Dimension(1390, 750));
        jPanel1.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                jPanel1AncestorAdded(evt);
            }
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Age.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jPanel1.add(Age, new org.netbeans.lib.awtextra.AbsoluteConstraints(104, 121, 81, -1));

        kButton1.setText("Update");
        kButton1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        kButton1.setkBorderRadius(60);
        kButton1.setkEndColor(new java.awt.Color(0, 0, 0));
        kButton1.setkHoverEndColor(new java.awt.Color(51, 255, 255));
        kButton1.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        kButton1.setkHoverStartColor(new java.awt.Color(0, 0, 0));
        kButton1.setkSelectedColor(new java.awt.Color(0, 153, 153));
        kButton1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                kButton1MouseClicked(evt);
            }
        });
        jPanel1.add(kButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 590, 152, -1));

        kButton3.setText("Delete");
        kButton3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        kButton3.setkBorderRadius(60);
        kButton3.setkEndColor(new java.awt.Color(0, 0, 0));
        kButton3.setkHoverEndColor(new java.awt.Color(51, 255, 255));
        kButton3.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        kButton3.setkHoverStartColor(new java.awt.Color(0, 0, 0));
        kButton3.setkSelectedColor(new java.awt.Color(0, 153, 153));
        kButton3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                kButton3MouseClicked(evt);
            }
        });
        jPanel1.add(kButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(940, 580, 152, -1));

        VoterTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        VoterTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                VoterTableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(VoterTable);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(471, 19, 622, 184));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Gender :");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 79, -1, -1));

        kButton5.setText("Add");
        kButton5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        kButton5.setkBorderRadius(60);
        kButton5.setkEndColor(new java.awt.Color(0, 0, 0));
        kButton5.setkHoverEndColor(new java.awt.Color(51, 255, 255));
        kButton5.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        kButton5.setkHoverStartColor(new java.awt.Color(0, 0, 0));
        kButton5.setkSelectedColor(new java.awt.Color(0, 153, 153));
        kButton5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                kButton5MouseClicked(evt);
            }
        });
        jPanel1.add(kButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(58, 586, 152, -1));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Voter ID :");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 260, -1, 40));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Age:");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(22, 117, -1, -1));

        Name.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jPanel1.add(Name, new org.netbeans.lib.awtextra.AbsoluteConstraints(104, 49, 272, -1));

        vcbGender.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        vcbGender.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Male", "Female" }));
        jPanel1.add(vcbGender, new org.netbeans.lib.awtextra.AbsoluteConstraints(104, 83, 116, -1));
        jPanel1.add(Pass, new org.netbeans.lib.awtextra.AbsoluteConstraints(109, 181, 255, -1));

        Input.setText("Input to Print");
        Input.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        Input.setkBorderRadius(60);
        Input.setkEndColor(new java.awt.Color(0, 0, 0));
        Input.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        Input.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                InputActionPerformed(evt);
            }
        });
        jPanel1.add(Input, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 310, 140, 26));

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Password:");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 177, -1, -1));

        Delete.setText("Reset");
        Delete.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        Delete.setkBorderRadius(60);
        Delete.setkEndColor(new java.awt.Color(0, 0, 0));
        Delete.setkHoverEndColor(new java.awt.Color(51, 255, 255));
        Delete.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        Delete.setkHoverStartColor(new java.awt.Color(0, 0, 0));
        Delete.setkSelectedColor(new java.awt.Color(0, 153, 153));
        Delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeleteActionPerformed(evt);
            }
        });
        jPanel1.add(Delete, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 590, 152, -1));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Section: ");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(22, 149, -1, -1));

        Section.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jPanel1.add(Section, new org.netbeans.lib.awtextra.AbsoluteConstraints(121, 153, 262, -1));

        Print.setText("Print");
        Print.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        Print.setkBorderRadius(60);
        Print.setkEndColor(new java.awt.Color(0, 0, 0));
        Print.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        Print.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PrintActionPerformed(evt);
            }
        });
        jPanel1.add(Print, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 360, 91, 26));

        txtReciept.setColumns(20);
        txtReciept.setRows(5);
        jScrollPane2.setViewportView(txtReciept);

        jPanel1.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 220, 620, 307));

        kButton6.setText("Search");
        kButton6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        kButton6.setkBorderRadius(60);
        kButton6.setkEndColor(new java.awt.Color(0, 0, 0));
        kButton6.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        kButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                kButton6ActionPerformed(evt);
            }
        });
        jPanel1.add(kButton6, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 270, 77, 26));
        jPanel1.add(VoterID, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 270, 150, -1));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Name :");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 45, -1, -1));

        javax.swing.GroupLayout jInternalFrame1Layout = new javax.swing.GroupLayout(jInternalFrame1.getContentPane());
        jInternalFrame1.getContentPane().setLayout(jInternalFrame1Layout);
        jInternalFrame1Layout.setHorizontalGroup(
            jInternalFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jInternalFrame1Layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 1129, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jInternalFrame1Layout.setVerticalGroup(
            jInternalFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
        );

        getContentPane().add(jInternalFrame1, new org.netbeans.lib.awtextra.AbsoluteConstraints(575, 329, 0, 0));

        kGradientPanel1.setkEndColor(new java.awt.Color(51, 102, 255));
        kGradientPanel1.setkGradientFocus(1100);
        kGradientPanel1.setkStartColor(new java.awt.Color(255, 51, 255));
        kGradientPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel11.setText("Password :");
        jPanel2.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 300, -1, -1));

        Password.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jPanel2.add(Password, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 300, 270, -1));

        section.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jPanel2.add(section, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 220, 230, -1));

        rbMale.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        rbMale.setText("Male");
        rbMale.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbMaleActionPerformed(evt);
            }
        });
        jPanel2.add(rbMale, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 140, -1, -1));

        Birthdate.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jPanel2.add(Birthdate, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 180, 270, -1));

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel10.setText("Year & Section : ");
        jPanel2.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 220, -1, -1));

        rbFemale.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        rbFemale.setText("Female");
        rbFemale.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbFemaleActionPerformed(evt);
            }
        });
        jPanel2.add(rbFemale, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 140, -1, -1));

        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel12.setText("Fullname :");
        jPanel2.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 100, 100, -1));

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel9.setText("Birthdate :");
        jPanel2.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 180, -1, -1));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel8.setText("Gender :");
        jPanel2.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 140, -1, -1));

        Username.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jPanel2.add(Username, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 260, 270, -1));

        jLabel13.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel13.setText("VOTERS REGISTRATION FORM");
        jPanel2.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 10, 270, -1));

        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnupdate.setText("Update");
        btnupdate.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnupdate.setkBorderRadius(60);
        btnupdate.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        btnupdate.setkHoverStartColor(new java.awt.Color(51, 51, 255));
        btnupdate.setkPressedColor(new java.awt.Color(51, 51, 255));
        btnupdate.setkSelectedColor(new java.awt.Color(51, 51, 255));
        btnupdate.setkStartColor(new java.awt.Color(0, 51, 153));
        btnupdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnupdateActionPerformed(evt);
            }
        });
        jPanel3.add(btnupdate, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 10, 81, -1));

        btnsave.setText("Save");
        btnsave.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnsave.setkBorderRadius(60);
        btnsave.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        btnsave.setkHoverStartColor(new java.awt.Color(102, 204, 0));
        btnsave.setkPressedColor(new java.awt.Color(0, 255, 0));
        btnsave.setkSelectedColor(new java.awt.Color(102, 255, 51));
        btnsave.setkStartColor(new java.awt.Color(51, 255, 0));
        btnsave.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnsaveMouseClicked(evt);
            }
        });
        btnsave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsaveActionPerformed(evt);
            }
        });
        jPanel3.add(btnsave, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 81, -1));

        btndelete.setText("Reset");
        btndelete.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btndelete.setkBorderRadius(60);
        btndelete.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        btndelete.setkHoverStartColor(new java.awt.Color(255, 51, 51));
        btndelete.setkPressedColor(new java.awt.Color(255, 0, 0));
        btndelete.setkSelectedColor(new java.awt.Color(255, 0, 0));
        btndelete.setkStartColor(new java.awt.Color(255, 102, 102));
        btndelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btndeleteActionPerformed(evt);
            }
        });
        jPanel3.add(btndelete, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 10, 81, -1));

        btnprint.setText("Print");
        btnprint.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnprint.setkBorderRadius(25);
        btnprint.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        btnprint.setkHoverStartColor(new java.awt.Color(255, 255, 0));
        btnprint.setkPressedColor(new java.awt.Color(204, 204, 0));
        btnprint.setkSelectedColor(new java.awt.Color(255, 255, 0));
        btnprint.setkStartColor(new java.awt.Color(204, 204, 0));
        btnprint.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnprintActionPerformed(evt);
            }
        });
        jPanel3.add(btnprint, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 80, 130, -1));

        btndelete1.setText("Delete");
        btndelete1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btndelete1.setkBorderRadius(60);
        btndelete1.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        btndelete1.setkHoverStartColor(new java.awt.Color(255, 51, 51));
        btndelete1.setkPressedColor(new java.awt.Color(255, 0, 0));
        btndelete1.setkSelectedColor(new java.awt.Color(255, 0, 0));
        btndelete1.setkStartColor(new java.awt.Color(255, 0, 0));
        btndelete1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btndelete1ActionPerformed(evt);
            }
        });
        jPanel3.add(btndelete1, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 10, 81, -1));

        btnimport1.setText("Export(Excel)");
        btnimport1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnimport1.setkBorderRadius(25);
        btnimport1.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        btnimport1.setkHoverStartColor(new java.awt.Color(51, 204, 0));
        btnimport1.setkPressedColor(new java.awt.Color(51, 153, 0));
        btnimport1.setkSelectedColor(new java.awt.Color(51, 153, 0));
        btnimport1.setkStartColor(new java.awt.Color(0, 102, 0));
        btnimport1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnimport1ActionPerformed(evt);
            }
        });
        jPanel3.add(btnimport1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 80, 130, -1));

        jPanel2.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 450, 380, 140));

        cbShow.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        cbShow.setText("Show");
        cbShow.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbShowActionPerformed(evt);
            }
        });
        jPanel2.add(cbShow, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 330, 60, 30));

        jLabel16.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel16.setText("Username : ");
        jPanel2.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 260, -1, -1));

        name.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jPanel2.add(name, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 100, 270, -1));
        jPanel2.add(jSeparator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 40, 270, 10));

        kGradientPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 50, 460, 650));

        jScrollPane3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        votertable.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        votertable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        votertable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                votertableMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(votertable);

        kGradientPanel1.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 430, 780, 270));

        Receipt.setColumns(20);
        Receipt.setRows(5);
        Receipt.setText("    \n");
        Receipt.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jScrollPane4.setViewportView(Receipt);

        kGradientPanel1.add(jScrollPane4, new org.netbeans.lib.awtextra.AbsoluteConstraints(870, 50, 430, 370));

        kButton7.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        kButton7.setIcon(new javax.swing.ImageIcon("C:\\Users\\User\\Desktop\\icons for java\\close32.png")); // NOI18N
        kButton7.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        kButton7.setkBorderRadius(30);
        kButton7.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        kButton7.setkHoverStartColor(new java.awt.Color(255, 51, 51));
        kButton7.setkPressedColor(new java.awt.Color(255, 51, 51));
        kButton7.setkSelectedColor(new java.awt.Color(255, 51, 51));
        kButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                kButton7ActionPerformed(evt);
            }
        });
        kGradientPanel1.add(kButton7, new org.netbeans.lib.awtextra.AbsoluteConstraints(1320, 10, 40, 60));

        jPanel4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel15.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel15.setText("Search Area");
        jPanel4.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 20, -1, 30));
        jPanel4.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 60, 200, 10));

        name1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        name1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                name1MouseClicked(evt);
            }
        });
        name1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                name1KeyReleased(evt);
            }
        });
        jPanel4.add(name1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 120, 250, -1));

        num.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        num.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        num.setText("0");
        num.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        num.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jPanel4.add(num, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 280, 130, 30));

        jLabel19.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel19.setText("Search Name Record");
        jPanel4.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 80, -1, 30));

        jLabel20.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel20.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel20.setText("Who Registered in the table ");
        jLabel20.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        jLabel20.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jLabel20.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jPanel4.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 210, -1, 30));

        jLabel21.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel21.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel21.setText("Number of Voter ");
        jLabel21.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        jLabel21.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jLabel21.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jPanel4.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 170, -1, 30));
        jPanel4.add(jSeparator3, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 320, 240, 10));

        kGradientPanel1.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 50, 340, 370));

        getContentPane().add(kGradientPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1390, 810));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void kButton1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kButton1MouseClicked
        // TODO add your handling code here:
       
    }//GEN-LAST:event_kButton1MouseClicked

    private void kButton3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kButton3MouseClicked
        // TODO add your handling code here:
       
    }//GEN-LAST:event_kButton3MouseClicked

    private void VoterTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_VoterTableMouseClicked
        // TODO add your handling code here:
       
    }//GEN-LAST:event_VoterTableMouseClicked

    private void kButton5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kButton5MouseClicked
        // TODO add your handling code here:
      
    }//GEN-LAST:event_kButton5MouseClicked

    private void InputActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_InputActionPerformed
        // TODO add your handling code here:
       
    }//GEN-LAST:event_InputActionPerformed

    private void DeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeleteActionPerformed
        // TODO add your handling code here:
       
    }//GEN-LAST:event_DeleteActionPerformed

    private void PrintActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PrintActionPerformed
       
       
       
    }//GEN-LAST:event_PrintActionPerformed

    private void kButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_kButton6ActionPerformed
     
   

    }//GEN-LAST:event_kButton6ActionPerformed

    private void jPanel1AncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_jPanel1AncestorAdded
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel1AncestorAdded

    private void rbMaleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbMaleActionPerformed
        // TODO add your handling code here:
         vgender = "Male";
        if(rbMale.isSelected()){
            rbFemale.setSelected(false);
        }
    }//GEN-LAST:event_rbMaleActionPerformed

    private void rbFemaleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbFemaleActionPerformed
        // TODO add your handling code here:
        vgender = "Female";
        if(rbFemale.isSelected()){
            rbMale.setSelected(false);
        }
    }//GEN-LAST:event_rbFemaleActionPerformed

    private void btnsaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsaveActionPerformed
        // TODO add your handling code here:
         if (Birthdate.getText().isEmpty() || name.getText().isEmpty()){
            JOptionPane.showMessageDialog(this, "Missing Information");

        }else {
            try {
                VoteCount();
                con=DriverManager.getConnection("jdbc:mysql://localhost/Moonstone","root","");
                PreparedStatement pst=con.prepareStatement(" INSERT INTO voter value(?,?,?,?,?,?,?)");
                pst.setInt(1, ID);
                pst.setString(2, name.getText());
                pst.setString(3,Birthdate.getText());
                pst.setString(4, vgender);
                pst.setString(5, section.getText());
                pst.setString(6,  Username.getText());
                pst.setString(7, Password.getText());
               

               
                int row=pst.executeUpdate();
                JOptionPane.showMessageDialog(this, "Voter now Registered");
                con.close();
                DisplayVoters();
                   Voter();
                   
                    
           
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, ex);
            }

        }
         
    
        Receipt.append("\t DCDNHS VOTING MANAGEMENT SYSTEM \n\n" +

          "\t****** V O T E R   R E C I E P T ********\n\n"+
         
            "FULLNAME:\t\t\t"+name.getText()+ "\n\n"+
            "YEAR & SECTION:\t\t"+section.getText()+ "\n\n"+
            "USERNAME:\t\t\t"+Username.getText()+ "\n\n"+
            "PASSWORD:\t\t\t"+Password.getText()+ "\n\n"+
            "\t **************VOTE WISELY!! ***************"
        );
       
    }//GEN-LAST:event_btnsaveActionPerformed

    private void btnsaveMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnsaveMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_btnsaveMouseClicked

    private void cbShowActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbShowActionPerformed
        // TODO add your handling code here:
          if(cbShow.isSelected()){
            Password.setEchoChar((char)0);
        }
        else{
            Password.setEchoChar(('*'));
        }
    }//GEN-LAST:event_cbShowActionPerformed
private JFrame frame;
    private void kButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_kButton7ActionPerformed
        // TODO add your handling code here:
        frame = new JFrame("Exit");
        if (JOptionPane.showConfirmDialog(this," Do you want to Exit? " ,"DCDNHS Automated Voting System",
            JOptionPane.YES_NO_OPTION) ==JOptionPane.YES_NO_OPTION)
    {
        new Admin_Dashboard().setVisible(true);
        this.dispose();;
        }
    }//GEN-LAST:event_kButton7ActionPerformed

    private void votertableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_votertableMouseClicked
        // TODO add your handling code here:
          DefaultTableModel model= (DefaultTableModel) votertable.getModel();
        int MyIndex = votertable.getSelectedRow();
        key = Integer.valueOf(model.getValueAt(MyIndex, 0).toString());
        name.setText(model.getValueAt(MyIndex, 1).toString());
         Birthdate.setText(model.getValueAt(MyIndex, 2).toString());
         String Gender = model.getValueAt(MyIndex,3).toString();
      
       if(Gender.equals("Male")){
          rbMale.setSelected(true);
          rbFemale.setSelected(false);
       
           
       }else{
            rbFemale.setSelected(true);
            rbMale.setSelected(false);
         
       }
        section.setText(model.getValueAt(MyIndex, 4).toString());
        Username.setText(model.getValueAt(MyIndex, 5).toString());
        Password.setText(model.getValueAt(MyIndex, 6).toString());
     name1.setText("");
        
    }//GEN-LAST:event_votertableMouseClicked

    private void btnupdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnupdateActionPerformed
        // TODO add your handling code here:
       
          if(key == -1 || name.getText().toString().isEmpty() || Birthdate.getText().toString().isEmpty() ){
            JOptionPane.showMessageDialog(this, "Missing Information");
        }else
             
        {
            try{

                con=DriverManager.getConnection("jdbc:mysql://localhost/Moonstone","root","");
                String Query = "Update voter set Name=?, Birthdate = ? ,Gender=?, YearSection=? ,Username=?, Password=? where vID=?";
                PreparedStatement UpdateQuery = con.prepareStatement(Query);
                UpdateQuery.setString (1,name.getText());
                  UpdateQuery.setString (2,Birthdate.getText());
                String selection;

            if(rbMale.isSelected()){
                selection = "Male";
            }
            else{
                selection = "Female";
            }
            
                UpdateQuery.setString(3,selection);
                UpdateQuery.setString (4,section.getText());
                 UpdateQuery.setString (5,Username.getText());
                  UpdateQuery.setString (6,Password.getText());
                  UpdateQuery.setInt(7,key);
            
                UpdateQuery.executeUpdate();

                JOptionPane.showMessageDialog(this, "Voter Updated Succesfully");
                DisplayVoters();
                    name.setText("");
                 Birthdate.setText("");
                     section.setText("");
                         Username.setText("");
                           Password.setText("");
                
            }catch(Exception e){
                JOptionPane.showMessageDialog(this, e);
            }

        }

    }//GEN-LAST:event_btnupdateActionPerformed
public void  Rerun(){
    
    new Voter().setVisible(true);
    setVisible(false);
    
    }
    private void btndeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btndeleteActionPerformed
        // TODO add your handling code here:
          
        Rerun();
    }//GEN-LAST:event_btndeleteActionPerformed

    private void btndelete1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btndelete1ActionPerformed
        // TODO add your handling code here:
            if(key== -1){
            JOptionPane.showMessageDialog(this, "Select The Voter To Be  Deleted");
        }else
        {
            try{

                con=DriverManager.getConnection("jdbc:mysql://localhost/Moonstone","root","");
                String Query = "Delete From voter where vID = "+key;
                Statement del = con.createStatement();
                del.executeUpdate(Query);
                JOptionPane.showMessageDialog(this, "Voter Deleted Succesfully");
                DisplayVoters();
                    name.setText("");
                 Birthdate.setText("");
                     section.setText("");
                         Username.setText("");
                           Password.setText("");
            }catch(Exception e){
                JOptionPane.showMessageDialog(this, e);
            }

        }
    }//GEN-LAST:event_btndelete1ActionPerformed

    private void btnprintActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnprintActionPerformed
        try {
            // TODO add your handling code here:
            Receipt.print();
        } catch (PrinterException ex) {
            Logger.getLogger(Voter.class.getName()).log(Level.SEVERE, null, ex);
        }
        
         Receipt.append("\t DCDNHS VOTING MANAGEMENT SYSTEM \n\n" +

          "\t****** V O T E R   R E C I E P T ********\n\n"+
         
            "FULLNAME:\t\t\t"+name.getText()+ "\n\n"+
            "YEAR & SECTION:\t\t"+section.getText()+ "\n\n"+
            "USERNAME:\t\t\t"+Username.getText()+ "\n\n"+
            "PASSWORD:\t\t\t"+Password.getText()+ "\n\n"+
            "\t **************VOTE WISELY!! ***************"
        );
    }//GEN-LAST:event_btnprintActionPerformed

    private void name1KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_name1KeyReleased
        // TODO add your handling code here:
        String Name = name1.getText();
        DefaultTableModel dtm = (DefaultTableModel) votertable.getModel();

        int r =votertable.getRowCount();
        while( r-- > 0){
        dtm.removeRow(r);
        
        }
        try {
          rs =Search.getdata(Name);
             while(rs.next()){
             
             java.util.Vector v = new java.util.Vector();
             
               v.add(rs.getString("vID"));
                    v.add(rs.getString("Name"));
                v.add(rs.getString("Birthdate"));
                    v.add(rs.getString("Gender"));
              v.add(rs.getString("YearSection"));
                    v.add(rs.getString("Username"));
                     v.add(rs.getString("Password"));
               dtm.addRow(v);
             }
            
        } catch (SQLException ex) {
          Logger.getLogger(Voter.class.getName()).log(Level.SEVERE, null, ex);
        }
          
    }//GEN-LAST:event_name1KeyReleased

    private void name1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_name1MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_name1MouseClicked

    private void btnimport1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnimport1ActionPerformed
 
JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Specify a file save");
        int userSelection = fileChooser.showSaveDialog(this);
        if(userSelection == JFileChooser.APPROVE_OPTION){
            File fileToSave = fileChooser.getSelectedFile();
            //lets write to file
         
            try {
                  FileWriter fw = new FileWriter(fileToSave);
                BufferedWriter bw = new BufferedWriter(fw);
                for (int i = 0; i < votertable.getRowCount(); i++) {
                    for (int j = 0; j < votertable.getColumnCount(); j++) {
                        //write
                        bw.write(votertable.getValueAt(i, j).toString()+"\t\t");
                    }
                    bw.newLine();//record per line 
                }
                JOptionPane.showMessageDialog(this, "SUCCESSFULLY LOADED","INFORMATION",JOptionPane.INFORMATION_MESSAGE);
                bw.close();
                fw.close();
            } catch (IOException ex) {
               JOptionPane.showMessageDialog(this, "ERROR","ERROR MESSAGE",JOptionPane.ERROR_MESSAGE);
            }
            
            
        }
    }//GEN-LAST:event_btnimport1ActionPerformed

    
   
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Voter.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Voter.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Voter.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Voter.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Voter().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField Age;
    private javax.swing.JTextField Birthdate;
    private com.k33ptoo.components.KButton Delete;
    private com.k33ptoo.components.KButton Input;
    private javax.swing.JTextField Name;
    private javax.swing.JTextField Pass;
    private javax.swing.JPasswordField Password;
    private com.k33ptoo.components.KButton Print;
    private javax.swing.JTextArea Receipt;
    private javax.swing.JTextField Section;
    private javax.swing.JTextField Username;
    private javax.swing.JTextField VoterID;
    private javax.swing.JTable VoterTable;
    private com.k33ptoo.components.KButton btndelete;
    private com.k33ptoo.components.KButton btndelete1;
    private com.k33ptoo.components.KButton btnimport1;
    private com.k33ptoo.components.KButton btnprint;
    private com.k33ptoo.components.KButton btnsave;
    private com.k33ptoo.components.KButton btnupdate;
    private javax.swing.JCheckBox cbShow;
    private javax.swing.JInternalFrame jInternalFrame1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private com.k33ptoo.components.KButton kButton1;
    private com.k33ptoo.components.KButton kButton3;
    private com.k33ptoo.components.KButton kButton5;
    private com.k33ptoo.components.KButton kButton6;
    private com.k33ptoo.components.KButton kButton7;
    private com.k33ptoo.components.KGradientPanel kGradientPanel1;
    private javax.swing.JTextField name;
    private javax.swing.JTextField name1;
    private javax.swing.JLabel num;
    private javax.swing.JRadioButton rbFemale;
    private javax.swing.JRadioButton rbMale;
    private javax.swing.JTextField section;
    private javax.swing.JTextArea txtReciept;
    private javax.swing.JComboBox<String> vcbGender;
    private javax.swing.JTable votertable;
    // End of variables declaration//GEN-END:variables
}
