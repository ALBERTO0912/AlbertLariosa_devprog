/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package dcdnhs.automated.voting.system;

import java.awt.BorderLayout;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import net.proteanit.sql.DbUtils;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import java.awt.Color;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;
import org.jfree.chart.ChartFrame;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.data.jdbc.JDBCCategoryDataset;
/**
 *
 * @author User
 */
public class Result extends javax.swing.JFrame {

    /**
     * Creates new form Result
     */
    public Result() {
        initComponents();      
         Display();
         VoteCount();
          DisplayCand();
    }
Connection con= null;
PreparedStatement pst= null;
ResultSet rs = null;
Statement st = null;

    public void VoteCount(){
  
        try {
            pst = con.prepareStatement("Select Count(*) AS VoteCount From cast_vote ");
            ResultSet rs = pst.executeQuery();
            while (rs.next()){
            int count = rs.getInt("VoteCount");
            
            num.setText(String.valueOf(count ));
            
            }
            
            
        } catch (SQLException ex) {
            Logger.getLogger(Voter.class.getName()).log(Level.SEVERE, null, ex);
        }
  
  }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jFreeChartResources1 = new org.jfree.chart.resources.JFreeChartResources();
        displayChart1 = new org.jfree.chart.servlet.DisplayChart();
        displayChart2 = new org.jfree.chart.servlet.DisplayChart();
        displayChart3 = new org.jfree.chart.servlet.DisplayChart();
        displayChart4 = new org.jfree.chart.servlet.DisplayChart();
        displayChart5 = new org.jfree.chart.servlet.DisplayChart();
        displayChart6 = new org.jfree.chart.servlet.DisplayChart();
        displayChart7 = new org.jfree.chart.servlet.DisplayChart();
        kGradientPanel1 = new com.k33ptoo.components.KGradientPanel();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jLabel3 = new javax.swing.JLabel();
        num = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel8 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jButton3 = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        name = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jTextField4 = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jTextField5 = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        Chart = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane5 = new javax.swing.JScrollPane();
        jTable4 = new javax.swing.JTable();
        jScrollPane4 = new javax.swing.JScrollPane();
        CandiateTbl = new javax.swing.JTable();
        jPanel5 = new javax.swing.JPanel();
        Count = new javax.swing.JLabel();
        Name = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        kGradientPanel1.setkEndColor(new java.awt.Color(255, 102, 255));
        kGradientPanel1.setkStartColor(new java.awt.Color(0, 204, 204));
        kGradientPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jScrollPane2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTable2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable2MouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(jTable2);

        jPanel1.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 40, 500, 210));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel3.setText("Number of Votes/Overall Record of Votes ");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 260, -1, -1));

        num.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        num.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        num.setText("0");
        jPanel1.add(num, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 290, 30, -1));
        jPanel1.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 330, 180, 10));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel8.setText("CAST VOTE TABLE");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 10, -1, -1));

        kGradientPanel1.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 50, 540, 350));

        jPanel4.setLayout(new javax.swing.BoxLayout(jPanel4, javax.swing.BoxLayout.LINE_AXIS));
        kGradientPanel1.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 410, 740, 260));

        jButton3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton3.setIcon(new javax.swing.ImageIcon("C:\\Users\\User\\Desktop\\icon\\Back.png")); // NOI18N
        jButton3.setText("Exit");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        kGradientPanel1.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(1280, 0, -1, 40));

        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel5.setText("Enter Canidate Result");
        jPanel3.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 160, -1, -1));

        jTextField1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jTextField1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jPanel3.add(jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 190, 280, 32));

        name.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        name.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jPanel3.add(name, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 50, 280, 32));

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel9.setText("Enter Winner Candidate");
        jPanel3.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 20, -1, -1));

        jTextField4.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jTextField4.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jPanel3.add(jTextField4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 260, 280, 32));

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel10.setText("Enter Canidate's Position");
        jPanel3.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 230, -1, -1));

        jButton2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton2.setText("Save & Submit (Excel)");
        jPanel3.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 310, 200, -1));

        jTextField5.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jTextField5.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jPanel3.add(jTextField5, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 120, 280, 32));

        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel11.setText("Enter Year & Section");
        jPanel3.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 90, -1, -1));

        kGradientPanel1.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 50, 340, 350));

        Chart.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        Chart.setIcon(new javax.swing.ImageIcon("C:\\Users\\User\\Desktop\\icon\\Back.png")); // NOI18N
        Chart.setText("Show Chart");
        Chart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ChartActionPerformed(evt);
            }
        });
        kGradientPanel1.add(Chart, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 470, 130, 90));

        jTable4.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane5.setViewportView(jTable4);

        CandiateTbl.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        CandiateTbl.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                CandiateTblMouseClicked(evt);
            }
        });
        jScrollPane4.setViewportView(CandiateTbl);

        jPanel5.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Count.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        Count.setText("0");
        jPanel5.add(Count, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 40, -1, -1));

        Name.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        Name.setText("Name");
        jPanel5.add(Name, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 10, -1, -1));

        jLabel14.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel14.setText("Candidate Result Count :");
        jPanel5.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 40, -1, -1));

        jLabel15.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel15.setText("Name of Candidate : ");
        jPanel5.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        kGradientPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(922, 50, -1, 620));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(kGradientPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 1445, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(kGradientPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 899, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents
 private void Display(){
    
    try{
     con=DriverManager.getConnection("jdbc:mysql://localhost/Moonstone","root","");
     st=con.createStatement();
     rs=st.executeQuery(" Select * from cast_vote ");
   jTable2.setModel(DbUtils.resultSetToTableModel(rs));
     
    }catch(Exception e){
    
    
    }
    }
 
  
    private void jTable2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable2MouseClicked
        // TODO add your handling code here:
      Display();
           
    }//GEN-LAST:event_jTable2MouseClicked
private JFrame frame;
    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
           frame = new JFrame("Exit");
        if (JOptionPane.showConfirmDialog(this," Do you want to Exit? " ,"DCDNHS Automated Voting System",
            JOptionPane.YES_NO_OPTION) ==JOptionPane.YES_NO_OPTION)
    {
        new Admin_Dashboard().setVisible(true);
         this.dispose();;
        }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void ChartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ChartActionPerformed
        try {
            // TODO add your handling code here:
            String query ="Select * from vote ";
            JDBCCategoryDataset dataset= new JDBCCategoryDataset(db.mycon(),query);
             JFreeChart jchart = ChartFactory.createBarChart3D("Candidate Result", "Candidate Name", "Student Candidate Marks", dataset,PlotOrientation.VERTICAL,true,true,false);
             BarRenderer renderer=null;
             CategoryPlot plot= jchart.getCategoryPlot();
            renderer=new BarRenderer();
           ChartFrame chartfm = new ChartFrame("Student Record",jchart,true);
            
           
            plot.setRangeGridlinePaint(Color.black);
            
         
            chartfm.setVisible(true);
            chartfm.setSize(500,400);
            ChartPanel chartpanel= new ChartPanel(jchart);
           jPanel4.removeAll();
            jPanel4.add(chartpanel);
            jPanel4.updateUI();

//jPanel4.setLayout(new BorderLayout());
//jPanel4.add(chartpanel, BorderLayout.NORTH);
        } catch (SQLException ex) {
            Logger.getLogger(Result.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_ChartActionPerformed
  int WinnerID,Votes;
    private void GetWinner(){
    
    
    try{    
        con=DriverManager.getConnection("jdbc:mysql://localhost/Moonstone","root","");
        st=con.createStatement();
      String Query = "Select  Count(DISTINCT President) From cast_vote Group By ID ORDER BY ID DESC LIMIT 1";
      rs = st.executeQuery(Query);
      while(rs.next()){
     //  JOptionPane.showMessageDialog(this,""+Votes);
       WinnerID=rs.getInt(1);
      }
      
    }catch(Exception e){
    JOptionPane.showMessageDialog(this,e);
    }
}
     private void GetVote(){
     
    
     try{    
      con=DriverManager.getConnection("jdbc:mysql://localhost/Moonstone","root","");
      st=con.createStatement();
      String Query = "Select  Count(DISTINCT President) From cast_vote Where ID="+WinnerID;
      rs = st.executeQuery(Query);
      while(rs.next()){
      // JOptionPane.showMessageDialog(this,""+Votes));
       Votes=rs.getInt(1);
       Count.setText(Votes+ " Votes");
      }
      
    }catch(Exception e){
    JOptionPane.showMessageDialog(this,e);
    }
    }
     
       private void DisplayCand(){
    
    try{
     con=DriverManager.getConnection("jdbc:mysql://localhost/Moonstone","root","");
     st=con.createStatement();
     rs=st.executeQuery(" Select cID,Name,Position from candidate");
   CandiateTbl.setModel(DbUtils.resultSetToTableModel(rs));
     
    }catch(Exception e){
    
    
    }
    }
    private void CandiateTblMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CandiateTblMouseClicked
        // TODO add your handling code here:
        DefaultTableModel model= (DefaultTableModel) CandiateTbl.getModel();
        int MyIndex = CandiateTbl.getSelectedRow();
        key = Integer.valueOf(model.getValueAt(MyIndex, 0).toString());
        Name.setText(model.getValueAt(MyIndex, 1).toString());
        Count.setText(model.getValueAt(MyIndex, 2).toString());
     DisplayCand();
        GetVote();
        GetWinner();
    }//GEN-LAST:event_CandiateTblMouseClicked
int key = -1;
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Result.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Result.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Result.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Result.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Result().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable CandiateTbl;
    private javax.swing.JButton Chart;
    private javax.swing.JLabel Count;
    private javax.swing.JLabel Name;
    private org.jfree.chart.servlet.DisplayChart displayChart1;
    private org.jfree.chart.servlet.DisplayChart displayChart2;
    private org.jfree.chart.servlet.DisplayChart displayChart3;
    private org.jfree.chart.servlet.DisplayChart displayChart4;
    private org.jfree.chart.servlet.DisplayChart displayChart5;
    private org.jfree.chart.servlet.DisplayChart displayChart6;
    private org.jfree.chart.servlet.DisplayChart displayChart7;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private org.jfree.chart.resources.JFreeChartResources jFreeChartResources1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTable jTable4;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;
    private com.k33ptoo.components.KGradientPanel kGradientPanel1;
    private javax.swing.JTextField name;
    private javax.swing.JLabel num;
    // End of variables declaration//GEN-END:variables
}
