/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package dcdnhs.automated.voting.system;

import java.sql.Statement;
import java.awt.Image;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;
import javax.swing.ComboBoxModel;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import net.proteanit.sql.DbUtils;

/**
 *
 * @author User
 */
public class Vote extends javax.swing.JFrame {

    /**
     * Creates new form Vote
     */
    public Vote() {
        initComponents();
       LoadPres();
       LoadvPres();
       LoadSec();
       LoadTres();
       LoadAud();
       LoadPIO();
       LoadPRO();
    }
    
    int VotingID;
    public Vote(int voterID){  
     initComponents();    
        Bravo.setVisible(false);
         LoadPres();
       LoadvPres();
       LoadSec();
       LoadTres();
       LoadAud();
       LoadPIO();
       LoadPRO();
         VotingID =voterID;
     JOptionPane.showMessageDialog(this,VotingID);
    }
    
 Connection con= null;
PreparedStatement pst= null;
ResultSet rs = null;
Statement st=null;

    public void LoadPres(){
  
  // load customer
  
      try {
          
          Statement s= db.mycon().createStatement();
          
          ResultSet rs = s.executeQuery("SELECT Name FROM Candidate where Position='President'");
          Vector v = new Vector();
          
          while (rs.next()) {              
              v.add(rs.getString("Name"));
              
              DefaultComboBoxModel com = new DefaultComboBoxModel(v);
              President.setModel(com);
               
          }
           
      } catch (SQLException e) {
            System.out.println(e);
      }
    }
     private void FetchPhoto(){
      String  name =President.getSelectedItem().toString();
    String query ="Select photo from Candidate where Name='"+name+"'";
    Statement st;
    ResultSet rs;
    try{
     con=DriverManager.getConnection("jdbc:mysql://localhost/Moonstone","root","");
    st=con.createStatement();
    rs=st.executeQuery(query);
    if(rs.next()){
    
    candidatephoto6.setIcon(ResizePhoto(null,rs.getBytes("Photo")));
    }
    
    }catch (Exception e){
    
    
    }
    }
     private ImageIcon ResizePhoto(String ImagePath, byte[] pic)
 {
 
 
     ImageIcon MyImage = null;
     
     if(ImagePath != null)
     {
 
     MyImage = new ImageIcon(ImagePath);
     } else
     
     {
         MyImage =  new ImageIcon(pic);
         }
 Image img = MyImage.getImage();
 Image newimg= img.getScaledInstance(candidatephoto.getWidth(), candidatephoto.getHeight(),Image.SCALE_SMOOTH);
 ImageIcon image=new ImageIcon(newimg);
         return image;
 }
    
    
    String imgpath=null;
     int vNumber;
     private void Vcheck(){
        
try{
    
    st1 = con.createStatement();
    rs1 =  st1.executeQuery("Select * From cast_vote Where vID="+VotingID+"");
  if (rs1.next())
  {
  
       vNumber=1;
    
  }else{
      
   vNumber=0;
  
  }

   
    }catch(Exception ex){
     JOptionPane.showMessageDialog(this, ex);
            }


}
     int key = -1;
     int ID;
    Statement st1 = null;
    ResultSet rs1= null;
    
    
    private void VoteCount(){
        
try{
    
    st1 = con.createStatement();
    rs1 =  st1.executeQuery("Select MAx (ID) From cast_vote");
    rs1.next();
    ID = rs1.getInt(1)+ 1;
    }catch(Exception ex){
            
            }


}
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        kGradientPanel1 = new com.k33ptoo.components.KGradientPanel();
        candidatephoto2 = new javax.swing.JLabel();
        Auditor = new javax.swing.JComboBox<>();
        candidatephoto = new javax.swing.JLabel();
        Secretary = new javax.swing.JComboBox<>();
        VicePresident = new javax.swing.JComboBox<>();
        candidatephoto1 = new javax.swing.JLabel();
        candidatephoto3 = new javax.swing.JLabel();
        Treasurer = new javax.swing.JComboBox<>();
        ProtocolOfficer = new javax.swing.JComboBox<>();
        candidatephoto4 = new javax.swing.JLabel();
        candidatephoto5 = new javax.swing.JLabel();
        PIO = new javax.swing.JComboBox<>();
        candidatephoto6 = new javax.swing.JLabel();
        President = new javax.swing.JComboBox<>();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        pres = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        VP = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        Sec = new javax.swing.JTextField();
        Tres = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        Aud = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        pio = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        Pro = new javax.swing.JTextField();
        id = new javax.swing.JLabel();
        Vote = new com.k33ptoo.components.KButton();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        Bravo = new javax.swing.JLabel();
        kButton7 = new com.k33ptoo.components.KButton();
        jLabel18 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        kGradientPanel1.setkEndColor(new java.awt.Color(0, 255, 255));
        kGradientPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        candidatephoto2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        candidatephoto2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        candidatephoto2.setText("Photo");
        candidatephoto2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 3));
        kGradientPanel1.add(candidatephoto2, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 450, 140, 160));

        Auditor.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        Auditor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AuditorActionPerformed(evt);
            }
        });
        kGradientPanel1.add(Auditor, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 650, 190, 40));

        candidatephoto.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        candidatephoto.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        candidatephoto.setText("Photo");
        candidatephoto.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 3));
        kGradientPanel1.add(candidatephoto, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 450, 140, 160));

        Secretary.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        Secretary.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SecretaryActionPerformed(evt);
            }
        });
        kGradientPanel1.add(Secretary, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 360, 190, 40));

        VicePresident.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        VicePresident.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                VicePresidentActionPerformed(evt);
            }
        });
        kGradientPanel1.add(VicePresident, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 360, 190, 40));

        candidatephoto1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        candidatephoto1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        candidatephoto1.setText("Photo");
        candidatephoto1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 3));
        kGradientPanel1.add(candidatephoto1, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 160, 140, 160));

        candidatephoto3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        candidatephoto3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        candidatephoto3.setText("Photo");
        candidatephoto3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 3));
        kGradientPanel1.add(candidatephoto3, new org.netbeans.lib.awtextra.AbsoluteConstraints(840, 160, 140, 160));

        Treasurer.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        Treasurer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TreasurerActionPerformed(evt);
            }
        });
        kGradientPanel1.add(Treasurer, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 360, 190, 40));

        ProtocolOfficer.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        ProtocolOfficer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ProtocolOfficerActionPerformed(evt);
            }
        });
        kGradientPanel1.add(ProtocolOfficer, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 650, 190, 40));

        candidatephoto4.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        candidatephoto4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        candidatephoto4.setText("Photo");
        candidatephoto4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 3));
        kGradientPanel1.add(candidatephoto4, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 440, 140, 160));

        candidatephoto5.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        candidatephoto5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        candidatephoto5.setText("Photo");
        candidatephoto5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 3));
        kGradientPanel1.add(candidatephoto5, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 160, 140, 160));

        PIO.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        PIO.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PIOActionPerformed(evt);
            }
        });
        kGradientPanel1.add(PIO, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 650, 190, 40));

        candidatephoto6.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        candidatephoto6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        candidatephoto6.setText("Photo");
        candidatephoto6.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 3));
        kGradientPanel1.add(candidatephoto6, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 160, 140, 160));

        President.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        President.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                PresidentMouseClicked(evt);
            }
        });
        President.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PresidentActionPerformed(evt);
            }
        });
        kGradientPanel1.add(President, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 360, 190, 40));

        jPanel1.setBackground(new java.awt.Color(204, 204, 204));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel2.setText("President");

        pres.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        pres.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel3.setText("YOUR CANDIDATE");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel4.setText("Vice President");

        VP.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        VP.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel5.setText("Secretary");

        Sec.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        Sec.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        Tres.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        Tres.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel6.setText("Treasurer");

        Aud.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        Aud.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel7.setText("Auditor");

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel8.setText("P.I.O");

        pio.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        pio.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel9.setText("Protocol Officer");

        Pro.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        Pro.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        id.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        id.setText("0");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(44, 44, 44)
                .addComponent(jLabel3))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addComponent(id)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(54, 54, 54)
                        .addComponent(jLabel2)
                        .addGap(64, 64, 64))
                    .addComponent(pres, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 198, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(VP, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 198, javax.swing.GroupLayout.PREFERRED_SIZE)))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(64, 64, 64)
                .addComponent(jLabel4))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(107, 107, 107)
                .addComponent(jLabel8))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(62, 62, 62)
                .addComponent(jLabel9))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Sec, javax.swing.GroupLayout.PREFERRED_SIZE, 198, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Aud, javax.swing.GroupLayout.PREFERRED_SIZE, 198, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(63, 63, 63)
                        .addComponent(jLabel5))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(60, 60, 60)
                        .addComponent(jLabel6))
                    .addComponent(Pro, javax.swing.GroupLayout.PREFERRED_SIZE, 198, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(71, 71, 71)
                        .addComponent(jLabel7))
                    .addComponent(pio, javax.swing.GroupLayout.PREFERRED_SIZE, 198, javax.swing.GroupLayout.PREFERRED_SIZE)))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(Tres, javax.swing.GroupLayout.PREFERRED_SIZE, 198, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(jLabel3)
                .addGap(33, 33, 33)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(pres, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(id))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(VP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Sec, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Tres, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Aud, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(pio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel9)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Pro, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(59, Short.MAX_VALUE))
        );

        kGradientPanel1.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(1100, 50, 250, 600));

        Vote.setText("Cast Vote");
        Vote.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        Vote.setkHoverForeGround(new java.awt.Color(255, 255, 0));
        Vote.setkHoverStartColor(new java.awt.Color(0, 204, 0));
        Vote.setkPressedColor(new java.awt.Color(51, 204, 0));
        Vote.setkSelectedColor(new java.awt.Color(102, 204, 0));
        Vote.setkStartColor(new java.awt.Color(0, 51, 0));
        Vote.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                VoteActionPerformed(evt);
            }
        });
        kGradientPanel1.add(Vote, new org.netbeans.lib.awtextra.AbsoluteConstraints(1130, 690, -1, -1));

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel10.setIcon(new javax.swing.ImageIcon("C:\\Users\\User\\Pictures\\Customer-removebg-preview.png")); // NOI18N
        jLabel10.setText("V O T E R   D A S H B O A R D ");
        kGradientPanel1.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 10, -1, -1));

        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel11.setText("Auditor");
        kGradientPanel1.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 620, -1, -1));

        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel12.setText("President");
        kGradientPanel1.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 330, -1, -1));

        jLabel13.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel13.setText("Vice President");
        kGradientPanel1.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 330, -1, -1));

        jLabel14.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel14.setText("Secretary");
        kGradientPanel1.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 330, -1, -1));

        jLabel16.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel16.setText("Protocol Officer");
        kGradientPanel1.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 620, -1, -1));

        jLabel17.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel17.setText("P.I.O");
        kGradientPanel1.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 620, -1, -1));

        Bravo.setBackground(new java.awt.Color(102, 255, 51));
        Bravo.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        Bravo.setText("Vote Counted !!!");
        kGradientPanel1.add(Bravo, new org.netbeans.lib.awtextra.AbsoluteConstraints(1160, 650, -1, -1));

        kButton7.setIcon(new javax.swing.ImageIcon("C:\\Users\\User\\Desktop\\icons for java\\close32.png")); // NOI18N
        kButton7.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        kButton7.setkBackGroundColor(new java.awt.Color(51, 255, 51));
        kButton7.setkBorderRadius(30);
        kButton7.setkEndColor(new java.awt.Color(51, 204, 0));
        kButton7.setkHoverEndColor(new java.awt.Color(0, 153, 0));
        kButton7.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        kButton7.setkHoverStartColor(new java.awt.Color(255, 51, 51));
        kButton7.setkPressedColor(new java.awt.Color(255, 51, 51));
        kButton7.setkSelectedColor(new java.awt.Color(255, 51, 51));
        kButton7.setkStartColor(new java.awt.Color(204, 204, 0));
        kButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                kButton7ActionPerformed(evt);
            }
        });
        kGradientPanel1.add(kButton7, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 40, 60));

        jLabel18.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel18.setText("Treasurer");
        kGradientPanel1.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(870, 330, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(kGradientPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 1405, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 6, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(kGradientPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 891, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void VoteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_VoteActionPerformed
        // TODO add your handling code here:
         Vcheck();
        if(VotingID == -1||pres.getText().toString().isEmpty()){

            JOptionPane.showMessageDialog(this, "Select Candidate or Select atleast 1 ");
        }else if(vNumber > 0){
            JOptionPane.showMessageDialog(this, "You Can Not Vote Twice !!!!");
        }else
        {
            try{

                con=DriverManager.getConnection("jdbc:mysql://localhost/Moonstone","root","");
                PreparedStatement add= con.prepareStatement("INSERT INTO cast_vote values (?,?,?,?,?,?,?,?,?)");
                add.setInt(1,ID);
                add.setInt(2,VotingID);    
                
                add.setString(3, pres.getText());
                 add.setString(4, VP.getText());
                  add.setString(5, Sec.getText());
                   add.setString(6, Tres.getText());
                    add.setString(7, Aud.getText());
                     add.setString(8, pio.getText());
                      add.setString(9, Pro.getText());
                     
                int row =add.executeUpdate();
                JOptionPane.showMessageDialog(this, "vote counted");
                JOptionPane.showMessageDialog(this, "Vote Succesfully ....thank you for voting!!");
                VoteCount();
                con.close();
                Bravo.setVisible(true);
                Vote.setVisible(false);
            }catch(Exception ex){
                JOptionPane.showMessageDialog(this, ex);
            }
        }
        
        
        try{
      String t=id.getText();
        String p=pres.getText();
           Statement ss = db.mycon().createStatement();
             ss.executeUpdate("INSERT INTO vote(ID,vID,cID,President) values('"+ID+"','"+VotingID+"','"+t+"','"+p+"')");
               
                
         } catch (NumberFormatException | SQLException e) {
            System.out.println(e);
        }
        
        
    }//GEN-LAST:event_VoteActionPerformed
public void LoadPIO(){
  
  // load customer
  
      try {
          
          Statement s= db.mycon().createStatement();
          
          ResultSet rs = s.executeQuery("SELECT Name FROM Candidate where Position='P.I.O'");
          Vector v = new Vector();
          
          while (rs.next()) {              
              v.add(rs.getString("Name"));
              
              DefaultComboBoxModel com = new DefaultComboBoxModel(v);
              PIO.setModel(com);
               
          }
           
      } catch (SQLException e) {
            System.out.println(e);
      }
    }
     private void FetchPhoto5(){
      String  name5 =PIO.getSelectedItem().toString();
    String query ="Select photo from Candidate where Name='"+name5+"'";
    Statement st;
    ResultSet rs;
    try{
     con=DriverManager.getConnection("jdbc:mysql://localhost/Moonstone","root","");
    st=con.createStatement();
    rs=st.executeQuery(query);
    if(rs.next()){
    
    candidatephoto.setIcon(ResizePhoto(null,rs.getBytes("Photo")));
    }
    
    }catch (Exception e){
    
    
    }
    }
    private void PIOActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PIOActionPerformed
        // TODO add your handling code here:
        String  name5 =PIO.getSelectedItem().toString();
                 pio.setText(name5);
        try {
            
            Statement s = db.mycon().createStatement();
            ResultSet rs = s.executeQuery("SELECT Name , Photo FROM Candidate WHERE Position = '"+name5+"'");
            if (rs.next()) {
                           
                candidatephoto.setText(rs.getString("Photo"));
                pio.setText(rs.getString("Name"));
           
            } 
        
           FetchPhoto5();
             
            
        } catch (SQLException e) {
            System.out.println(e);
        }        // TODO add your handling code here:
        
    }//GEN-LAST:event_PIOActionPerformed

    private void PresidentMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PresidentMouseClicked
             
    }//GEN-LAST:event_PresidentMouseClicked

    private void PresidentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PresidentActionPerformed
        // TODO add your handling code here:
           String  name =President.getSelectedItem().toString();
                 pres.setText(name);
        try {
            
            Statement s = db.mycon().createStatement();
            ResultSet rs = s.executeQuery("SELECT cID,Name,Photo FROM Candidate WHERE Position = '"+name+"'");
            if (rs.next()) {
                           
                candidatephoto6.setText(rs.getString("Photo"));
                pres.setText(rs.getString("Name"));
                   id.setText(rs.getString("cID"));
            } 
        
           FetchPhoto();
             
            
        } catch (SQLException e) {
            System.out.println(e);
        }        // TODO add your handling code here:
        
    }//GEN-LAST:event_PresidentActionPerformed
 public void LoadvPres(){
  
  // load customer
  
      try {
          
          Statement s= db.mycon().createStatement();
          
          ResultSet rs = s.executeQuery("SELECT Name FROM Candidate where Position='Vice President'");
          Vector v = new Vector();
          
          while (rs.next()) {              
              v.add(rs.getString("Name"));
              
              DefaultComboBoxModel com = new DefaultComboBoxModel(v);
              VicePresident.setModel(com);
               
          }
           
      } catch (SQLException e) {
            System.out.println(e);
      }
    }
     private void FetchPhoto1(){
      String  name1 =VicePresident.getSelectedItem().toString();
    String query ="Select photo from Candidate where Name='"+name1+"'";
    Statement st;
    ResultSet rs;
    try{
     con=DriverManager.getConnection("jdbc:mysql://localhost/Moonstone","root","");
    st=con.createStatement();
    rs=st.executeQuery(query);
    if(rs.next()){
    
    candidatephoto1.setIcon(ResizePhoto(null,rs.getBytes("Photo")));
    }
    
    }catch (Exception e){
    
    
    }
    }
    private void VicePresidentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_VicePresidentActionPerformed
        // TODO add your handling code here:
         String  name1 =VicePresident.getSelectedItem().toString();
                 VP.setText(name1);
        try {
            
            Statement s = db.mycon().createStatement();
            ResultSet rs = s.executeQuery("SELECT Name , Photo FROM Candidate WHERE Position = '"+name1+"'");
            if (rs.next()) {
                           
                candidatephoto1.setText(rs.getString("Photo"));
                VP.setText(rs.getString("Name"));
           
            } 
        
           FetchPhoto1();
             
            
        } catch (SQLException e) {
            System.out.println(e);
        }        // TODO add your handling code here:
    }//GEN-LAST:event_VicePresidentActionPerformed
public void LoadSec(){
  
  // load customer
  
      try {
          
          Statement s= db.mycon().createStatement();
          
          ResultSet rs = s.executeQuery("SELECT Name FROM Candidate where Position='Secretary'");
          Vector v = new Vector();
          
          while (rs.next()) {              
              v.add(rs.getString("Name"));
              
              DefaultComboBoxModel com = new DefaultComboBoxModel(v);
              Secretary.setModel(com);
               
          }
           
      } catch (SQLException e) {
            System.out.println(e);
      }
    }
     private void FetchPhoto2(){
      String  name2 =Secretary.getSelectedItem().toString();
    String query ="Select photo from Candidate where Name='"+name2+"'";
    Statement st;
    ResultSet rs;
    try{
     con=DriverManager.getConnection("jdbc:mysql://localhost/Moonstone","root","");
    st=con.createStatement();
    rs=st.executeQuery(query);
    if(rs.next()){
    
    candidatephoto5.setIcon(ResizePhoto(null,rs.getBytes("Photo")));
    }
    
    }catch (Exception e){
    
    
    }
    }
    private void SecretaryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SecretaryActionPerformed
        // TODO add your handling code here:
         String  name2 =Secretary.getSelectedItem().toString();
                 Sec.setText(name2);
        try {
            
            Statement s = db.mycon().createStatement();
            ResultSet rs = s.executeQuery("SELECT Name , Photo FROM Candidate WHERE Position = '"+name2+"'");
            if (rs.next()) {
                           
                candidatephoto5.setText(rs.getString("Photo"));
                Sec.setText(rs.getString("Name"));
           
            } 
        
           FetchPhoto2();
             
            
        } catch (SQLException e) {
            System.out.println(e);
        }        // TODO add your handling code here:
    }//GEN-LAST:event_SecretaryActionPerformed
private JFrame frame;
    private void kButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_kButton7ActionPerformed
        // TODO add your handling code here:
        frame = new JFrame("Exit");
        if (JOptionPane.showConfirmDialog(this," Do you want to Exit? " ,"DCDNHS Automated Voting System",
            JOptionPane.YES_NO_OPTION) ==JOptionPane.YES_NO_OPTION)
    {
        new Login().setVisible(true);
        this.dispose();;
        }
    }//GEN-LAST:event_kButton7ActionPerformed
public void LoadTres(){
  
  // load customer
  
      try {
          
          Statement s= db.mycon().createStatement();
          
          ResultSet rs = s.executeQuery("SELECT Name FROM Candidate where Position='Treasurer'");
          Vector v = new Vector();
          
          while (rs.next()) {              
              v.add(rs.getString("Name"));
              
              DefaultComboBoxModel com = new DefaultComboBoxModel(v);
              Treasurer.setModel(com);
               
          }
           
      } catch (SQLException e) {
            System.out.println(e);
      }
    }
     private void FetchPhoto3(){
      String  name3 =Treasurer.getSelectedItem().toString();
    String query ="Select photo from Candidate where Name='"+name3+"'";
    Statement st;
    ResultSet rs;
    try{
     con=DriverManager.getConnection("jdbc:mysql://localhost/Moonstone","root","");
    st=con.createStatement();
    rs=st.executeQuery(query);
    if(rs.next()){
    
    candidatephoto3.setIcon(ResizePhoto(null,rs.getBytes("Photo")));
    }
    
    }catch (Exception e){
    
    
    }
    }
    private void TreasurerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TreasurerActionPerformed
        // TODO add your handling code here:
        
         String  name3 =Treasurer.getSelectedItem().toString();
                 Tres.setText(name3);
        try {
            
            Statement s = db.mycon().createStatement();
            ResultSet rs = s.executeQuery("SELECT cID, Name , Photo FROM Candidate WHERE Position = '"+name3+"'");
            if (rs.next()) {
                
              
                candidatephoto3.setText(rs.getString("Photo"));
                Tres.setText(rs.getString("Name"));
                
            } 
        
           FetchPhoto3();
             
            
        } catch (SQLException e) {
            System.out.println(e);
        }        // TODO add your
    }//GEN-LAST:event_TreasurerActionPerformed
public void LoadAud(){
  
  // load customer
  
      try {
          
          Statement s= db.mycon().createStatement();
          
          ResultSet rs = s.executeQuery("SELECT Name FROM Candidate where Position='Auditor'");
          Vector v = new Vector();
          
          while (rs.next()) {              
              v.add(rs.getString("Name"));
              
              DefaultComboBoxModel com = new DefaultComboBoxModel(v);
              Auditor.setModel(com);
               
          }
           
      } catch (SQLException e) {
            System.out.println(e);
      }
    }
     private void FetchPhoto4(){
      String  name4 =Auditor.getSelectedItem().toString();
    String query ="Select photo from Candidate where Name='"+name4+"'";
    Statement st;
    ResultSet rs;
    try{
     con=DriverManager.getConnection("jdbc:mysql://localhost/Moonstone","root","");
    st=con.createStatement();
    rs=st.executeQuery(query);
    if(rs.next()){
    
    candidatephoto2.setIcon(ResizePhoto(null,rs.getBytes("Photo")));
    }
    
    }catch (Exception e){
    
    
    }
    }
    private void AuditorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AuditorActionPerformed
        // TODO add your handling code here:
         String  name4 =Auditor.getSelectedItem().toString();
                 Aud.setText(name4);
        try {
            
            Statement s = db.mycon().createStatement();
            ResultSet rs = s.executeQuery("SELECT Name , Photo FROM Candidate WHERE Position = '"+name4+"'");
            if (rs.next()) {
                           
                candidatephoto2.setText(rs.getString("Photo"));
                Aud.setText(rs.getString("Name"));
           
            } 
        
           FetchPhoto4();
             
            
        } catch (SQLException e) {
            System.out.println(e);
        }        // TODO add your
    }//GEN-LAST:event_AuditorActionPerformed
public void LoadPRO(){
  
  // load customer
  
      try {
          
          Statement s= db.mycon().createStatement();
          
          ResultSet rs = s.executeQuery("SELECT Name FROM Candidate where Position='Protocol Officer'");
          Vector v = new Vector();
          
          while (rs.next()) {              
              v.add(rs.getString("Name"));
              
              DefaultComboBoxModel com = new DefaultComboBoxModel(v);
              ProtocolOfficer.setModel(com);
               
          }
           
      } catch (SQLException e) {
            System.out.println(e);
      }
    }
     private void FetchPhoto6(){
      String  name4 =ProtocolOfficer.getSelectedItem().toString();
    String query ="Select photo from Candidate where Name='"+name4+"'";
    Statement st;
    ResultSet rs;
    try{
     con=DriverManager.getConnection("jdbc:mysql://localhost/Moonstone","root","");
    st=con.createStatement();
    rs=st.executeQuery(query);
    if(rs.next()){
    
    candidatephoto4.setIcon(ResizePhoto(null,rs.getBytes("Photo")));
    }
    
    }catch (Exception e){
    
    
    }
    }
    private void ProtocolOfficerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ProtocolOfficerActionPerformed
        // TODO add your handling code here:
          String  name6 =ProtocolOfficer.getSelectedItem().toString();
                 Pro.setText(name6);
        try {
            
            Statement s = db.mycon().createStatement();
            ResultSet rs = s.executeQuery("SELECT Name , Photo FROM Candidate WHERE Position = '"+name6+"'");
            if (rs.next()) {
                           
                candidatephoto4.setText(rs.getString("Photo"));
                Pro.setText(rs.getString("Name"));
           
            } 
        
           FetchPhoto6();
             
            
        } catch (SQLException e) {
            System.out.println(e);
        }        // TODO add your
        
        
    }//GEN-LAST:event_ProtocolOfficerActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Vote.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Vote.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Vote.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Vote.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Vote().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField Aud;
    private javax.swing.JComboBox<String> Auditor;
    private javax.swing.JLabel Bravo;
    private javax.swing.JComboBox<String> PIO;
    private javax.swing.JComboBox<String> President;
    private javax.swing.JTextField Pro;
    private javax.swing.JComboBox<String> ProtocolOfficer;
    private javax.swing.JTextField Sec;
    private javax.swing.JComboBox<String> Secretary;
    private javax.swing.JComboBox<String> Treasurer;
    private javax.swing.JTextField Tres;
    private javax.swing.JTextField VP;
    private javax.swing.JComboBox<String> VicePresident;
    private com.k33ptoo.components.KButton Vote;
    private javax.swing.JLabel candidatephoto;
    private javax.swing.JLabel candidatephoto1;
    private javax.swing.JLabel candidatephoto2;
    private javax.swing.JLabel candidatephoto3;
    private javax.swing.JLabel candidatephoto4;
    private javax.swing.JLabel candidatephoto5;
    private javax.swing.JLabel candidatephoto6;
    private javax.swing.JLabel id;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private com.k33ptoo.components.KButton kButton7;
    private com.k33ptoo.components.KGradientPanel kGradientPanel1;
    private javax.swing.JTextField pio;
    private javax.swing.JTextField pres;
    // End of variables declaration//GEN-END:variables
}
