/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package dcdnhs.automated.voting.system;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 *
 * @author User
 */
public class Admin_Dashboard extends javax.swing.JFrame {

    
    public Admin_Dashboard() {
        initComponents();
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jFreeChartResources1 = new org.jfree.chart.resources.JFreeChartResources();
        datasetGroup1 = new org.jfree.data.general.DatasetGroup();
        jFreeChartResources2 = new org.jfree.chart.resources.JFreeChartResources();
        chartRenderingInfo1 = new org.jfree.chart.ChartRenderingInfo();
        jFreeChartResources3 = new org.jfree.chart.resources.JFreeChartResources();
        kGradientPanel1 = new com.k33ptoo.components.KGradientPanel();
        jLabel4 = new javax.swing.JLabel();
        kButton1 = new com.k33ptoo.components.KButton();
        kButton2 = new com.k33ptoo.components.KButton();
        kButton3 = new com.k33ptoo.components.KButton();
        jLabel3 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        kButton7 = new com.k33ptoo.components.KButton();
        jSeparator1 = new javax.swing.JSeparator();
        jSeparator2 = new javax.swing.JSeparator();
        jSeparator3 = new javax.swing.JSeparator();
        jSeparator4 = new javax.swing.JSeparator();
        jSeparator5 = new javax.swing.JSeparator();
        jSeparator6 = new javax.swing.JSeparator();
        jSeparator7 = new javax.swing.JSeparator();
        jSeparator8 = new javax.swing.JSeparator();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        kGradientPanel1.setkEndColor(new java.awt.Color(0, 204, 204));
        kGradientPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setIcon(new javax.swing.ImageIcon("C:\\Users\\User\\Pictures\\User-removebg-preview.png")); // NOI18N
        jLabel4.setText("A D M I N ");
        jLabel4.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jLabel4.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        kGradientPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 20, 370, 200));

        kButton1.setText("RESULT");
        kButton1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        kButton1.setkHoverEndColor(new java.awt.Color(0, 102, 0));
        kButton1.setkHoverForeGround(new java.awt.Color(255, 255, 0));
        kButton1.setkHoverStartColor(new java.awt.Color(51, 153, 0));
        kButton1.setkPressedColor(new java.awt.Color(0, 102, 0));
        kButton1.setkSelectedColor(new java.awt.Color(0, 153, 0));
        kButton1.setkStartColor(new java.awt.Color(0, 0, 0));
        kButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                kButton1ActionPerformed(evt);
            }
        });
        kGradientPanel1.add(kButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(1020, 470, -1, -1));

        kButton2.setText("CANDIDATE REGISTRATION");
        kButton2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        kButton2.setkHoverEndColor(new java.awt.Color(0, 102, 0));
        kButton2.setkHoverForeGround(new java.awt.Color(255, 255, 0));
        kButton2.setkHoverStartColor(new java.awt.Color(51, 153, 0));
        kButton2.setkPressedColor(new java.awt.Color(0, 102, 0));
        kButton2.setkSelectedColor(new java.awt.Color(0, 153, 0));
        kButton2.setkStartColor(new java.awt.Color(0, 0, 0));
        kButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                kButton2ActionPerformed(evt);
            }
        });
        kGradientPanel1.add(kButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 470, -1, -1));

        kButton3.setText("VOTER REGISTRATION");
        kButton3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        kButton3.setkHoverEndColor(new java.awt.Color(0, 102, 0));
        kButton3.setkHoverForeGround(new java.awt.Color(255, 255, 0));
        kButton3.setkHoverStartColor(new java.awt.Color(51, 153, 0));
        kButton3.setkPressedColor(new java.awt.Color(0, 102, 0));
        kButton3.setkSelectedColor(new java.awt.Color(0, 153, 0));
        kButton3.setkStartColor(new java.awt.Color(0, 0, 0));
        kButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                kButton3ActionPerformed(evt);
            }
        });
        kGradientPanel1.add(kButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 470, -1, -1));

        jLabel3.setIcon(new javax.swing.ImageIcon("C:\\Users\\User\\Downloads\\Graph-removebg-preview.png")); // NOI18N
        kGradientPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(1050, 320, -1, -1));

        jLabel6.setIcon(new javax.swing.ImageIcon("C:\\Users\\User\\Desktop\\icon\\people.png")); // NOI18N
        kGradientPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 330, -1, -1));

        jLabel7.setIcon(new javax.swing.ImageIcon("C:\\Users\\User\\Pictures\\Customer-removebg-preview.png")); // NOI18N
        kGradientPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 320, -1, -1));

        kButton7.setIcon(new javax.swing.ImageIcon("C:\\Users\\User\\Desktop\\icons for java\\close32.png")); // NOI18N
        kButton7.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        kButton7.setkBorderRadius(30);
        kButton7.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        kButton7.setkHoverStartColor(new java.awt.Color(255, 51, 51));
        kButton7.setkPressedColor(new java.awt.Color(255, 51, 51));
        kButton7.setkSelectedColor(new java.awt.Color(255, 51, 51));
        kButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                kButton7ActionPerformed(evt);
            }
        });
        kGradientPanel1.add(kButton7, new org.netbeans.lib.awtextra.AbsoluteConstraints(1310, 10, 40, 60));

        jSeparator1.setForeground(new java.awt.Color(255, 51, 51));
        jSeparator1.setOrientation(javax.swing.SwingConstants.VERTICAL);
        kGradientPanel1.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 160, 20, 200));

        jSeparator2.setForeground(new java.awt.Color(255, 255, 0));
        kGradientPanel1.add(jSeparator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 130, 390, 10));

        jSeparator3.setForeground(new java.awt.Color(255, 255, 0));
        jSeparator3.setOrientation(javax.swing.SwingConstants.VERTICAL);
        kGradientPanel1.add(jSeparator3, new org.netbeans.lib.awtextra.AbsoluteConstraints(1130, 130, 20, 220));

        jSeparator4.setForeground(new java.awt.Color(0, 51, 255));
        jSeparator4.setOrientation(javax.swing.SwingConstants.VERTICAL);
        kGradientPanel1.add(jSeparator4, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 130, 20, 200));

        jSeparator5.setForeground(new java.awt.Color(0, 102, 255));
        jSeparator5.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jSeparator5.setName(""); // NOI18N
        kGradientPanel1.add(jSeparator5, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 130, 390, 10));
        kGradientPanel1.add(jSeparator6, new org.netbeans.lib.awtextra.AbsoluteConstraints(1010, 530, 210, 20));
        kGradientPanel1.add(jSeparator7, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 530, 210, 20));
        kGradientPanel1.add(jSeparator8, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 530, 210, 20));

        getContentPane().add(kGradientPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1390, 800));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void kButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_kButton2ActionPerformed
        // TODO add your handling code here:
         new Candidate().setVisible(true);
         this.dispose();
    }//GEN-LAST:event_kButton2ActionPerformed

    private void kButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_kButton3ActionPerformed
        // TODO add your handling code here:
          new Voter().setVisible(true);
         this.dispose();
    }//GEN-LAST:event_kButton3ActionPerformed
private JFrame frame;
    private void kButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_kButton7ActionPerformed
        // TODO add your handling code here:
        frame = new JFrame("Exit");
        if (JOptionPane.showConfirmDialog(this," Do you want to Exit? " ,"DCDNHS Automated Voting System",
            JOptionPane.YES_NO_OPTION) ==JOptionPane.YES_NO_OPTION)
    {
        new Login().setVisible(true);
        this.dispose();;
        }
    }//GEN-LAST:event_kButton7ActionPerformed

    private void kButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_kButton1ActionPerformed
        // TODO add your handling code here:
        
         new Result().setVisible(true);
         this.dispose();
        
    }//GEN-LAST:event_kButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Admin_Dashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Admin_Dashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Admin_Dashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Admin_Dashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Admin_Dashboard().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private org.jfree.chart.ChartRenderingInfo chartRenderingInfo1;
    private org.jfree.data.general.DatasetGroup datasetGroup1;
    private org.jfree.chart.resources.JFreeChartResources jFreeChartResources1;
    private org.jfree.chart.resources.JFreeChartResources jFreeChartResources2;
    private org.jfree.chart.resources.JFreeChartResources jFreeChartResources3;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JSeparator jSeparator5;
    private javax.swing.JSeparator jSeparator6;
    private javax.swing.JSeparator jSeparator7;
    private javax.swing.JSeparator jSeparator8;
    private com.k33ptoo.components.KButton kButton1;
    private com.k33ptoo.components.KButton kButton2;
    private com.k33ptoo.components.KButton kButton3;
    private com.k33ptoo.components.KButton kButton7;
    private com.k33ptoo.components.KGradientPanel kGradientPanel1;
    // End of variables declaration//GEN-END:variables
}
