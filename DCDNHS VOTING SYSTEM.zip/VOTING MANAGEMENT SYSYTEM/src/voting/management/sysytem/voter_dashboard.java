/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package voting.management.sysytem;

import java.awt.Image;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import net.proteanit.sql.DbUtils;


public class voter_dashboard extends javax.swing.JFrame {

    
    public voter_dashboard() {
        initComponents();
        DisplayCand();
       DisplayVice();
         DisplaySecretary();
         DisplayTreasurer();
          DisplayAuditor();;
           DisplayPIO();
           DisplayProtocolOfficer();
    }
int VotingID;
    public voter_dashboard(int voterID){  
     initComponents();
        DisplayCand();  
        DisplayVice();
        DisplaySecretary();
        DisplayTreasurer();
         DisplayAuditor();
          DisplayPIO();
          DisplayProtocolOfficer();
        bravo.setVisible(false);
        bravo4.setVisible(false);
         bravo3.setVisible(false);
          bravo5.setVisible(false);
           bravo2.setVisible(false);
            bravo1.setVisible(false);
             bravo7.setVisible(false);
             bravo8.setVisible(false);
         VotingID =voterID;
     JOptionPane.showMessageDialog(this,VotingID);
    }
    
 Connection con= null;
PreparedStatement pst= null;
ResultSet rs = null;
Statement st = null;

 private void DisplayCand(){
    
    try{
     con=DriverManager.getConnection("jdbc:mysql://localhost/Moonstone","root","");
     st=con.createStatement();
     rs=st.executeQuery("Select cID,Name,Section,Position from candidate where Position = 'President'");
   jTable1.setModel(DbUtils.resultSetToTableModel(rs));
     
    }catch(Exception e){
    
    
    }
    }
 private void FetchPhoto(){
    
    String query ="Select photo from candidate where cID="+key;
    Statement st;
    ResultSet rs;
    try{
     con=DriverManager.getConnection("jdbc:mysql://localhost/Moonstone","root","");
    st=con.createStatement();
    rs=st.executeQuery(query);
    if(rs.next()){
    
    candidatephoto.setIcon(ResizePhoto(null,rs.getBytes("Photo")));
    }
    
    }catch (Exception e){
    
    
    }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        save1 = new com.k33ptoo.components.KButton();
        bravo2 = new javax.swing.JLabel();
        kGradientPanel2 = new com.k33ptoo.components.KGradientPanel();
        candidatephoto2 = new javax.swing.JLabel();
        btnVP = new com.k33ptoo.components.KButton();
        jSeparator1 = new javax.swing.JSeparator();
        bravo5 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        treasurer = new com.k33ptoo.components.KButton();
        jLabel15 = new javax.swing.JLabel();
        candidatephoto1 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTable3 = new javax.swing.JTable();
        jLabel6 = new javax.swing.JLabel();
        bravo = new javax.swing.JLabel();
        candidatephoto3 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel12 = new javax.swing.JLabel();
        jScrollPane8 = new javax.swing.JScrollPane();
        jTable8 = new javax.swing.JTable();
        ProtocolOfficer = new com.k33ptoo.components.KButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        Secretary = new com.k33ptoo.components.KButton();
        jLabel5 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        candidatephoto5 = new javax.swing.JLabel();
        bravo1 = new javax.swing.JLabel();
        jScrollPane6 = new javax.swing.JScrollPane();
        jTable6 = new javax.swing.JTable();
        candidatephoto = new javax.swing.JLabel();
        bravo3 = new javax.swing.JLabel();
        bravo8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        jTable4 = new javax.swing.JTable();
        Auditor = new com.k33ptoo.components.KButton();
        jScrollPane5 = new javax.swing.JScrollPane();
        jTable5 = new javax.swing.JTable();
        bravo4 = new javax.swing.JLabel();
        candidatephoto4 = new javax.swing.JLabel();
        bravo7 = new javax.swing.JLabel();
        kGradientPanel1 = new com.k33ptoo.components.KGradientPanel();
        kButton1 = new com.k33ptoo.components.KButton();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        kButton2 = new com.k33ptoo.components.KButton();
        jLabel4 = new javax.swing.JLabel();
        candidatephoto7 = new javax.swing.JLabel();
        save = new com.k33ptoo.components.KButton();
        jLabel10 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        PIO = new com.k33ptoo.components.KButton();
        jSeparator2 = new javax.swing.JSeparator();
        jSeparator3 = new javax.swing.JSeparator();
        jSeparator5 = new javax.swing.JSeparator();
        jSeparator6 = new javax.swing.JSeparator();
        jSeparator7 = new javax.swing.JSeparator();
        jSeparator8 = new javax.swing.JSeparator();
        jSeparator9 = new javax.swing.JSeparator();
        jTextField1 = new javax.swing.JTextField();
        Name5 = new javax.swing.JTextField();
        Name6 = new javax.swing.JTextField();
        Name8 = new javax.swing.JTextField();
        Name2 = new javax.swing.JTextField();
        Name3 = new javax.swing.JTextField();
        Name4 = new javax.swing.JTextField();
        jSeparator10 = new javax.swing.JSeparator();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(102, 102, 255));
        jPanel1.setPreferredSize(new java.awt.Dimension(1431, 737));

        save1.setText("Vote");
        save1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        save1.setkBorderRadius(60);
        save1.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        save1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                save1MouseClicked(evt);
            }
        });

        bravo2.setBackground(new java.awt.Color(102, 255, 51));
        bravo2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        bravo2.setForeground(new java.awt.Color(102, 255, 51));

        kGradientPanel2.setkEndColor(new java.awt.Color(0, 153, 153));
        kGradientPanel2.setkStartColor(new java.awt.Color(102, 102, 102));
        kGradientPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        candidatephoto2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        candidatephoto2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        candidatephoto2.setText("Photo");
        candidatephoto2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 3));
        kGradientPanel2.add(candidatephoto2, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 430, 200, 100));

        btnVP.setText("Vote");
        btnVP.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnVP.setkBorderRadius(60);
        btnVP.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        btnVP.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnVPMouseClicked(evt);
            }
        });
        kGradientPanel2.add(btnVP, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 330, 60, 33));
        kGradientPanel2.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 380, 1387, 10));

        bravo5.setBackground(new java.awt.Color(102, 255, 51));
        bravo5.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        bravo5.setForeground(new java.awt.Color(102, 255, 51));
        bravo5.setText("Vote Counted !!! ");
        kGradientPanel2.add(bravo5, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 170, -1, -1));

        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel11.setText("SECRETARY");
        kGradientPanel2.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 10, -1, -1));

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel7.setText("PROTOCOL OFFICER");
        kGradientPanel2.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 390, -1, -1));

        treasurer.setText("Vote");
        treasurer.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        treasurer.setkBorderRadius(60);
        treasurer.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        treasurer.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                treasurerMouseClicked(evt);
            }
        });
        treasurer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                treasurerActionPerformed(evt);
            }
        });
        kGradientPanel2.add(treasurer, new org.netbeans.lib.awtextra.AbsoluteConstraints(1270, 330, 70, 32));

        jLabel15.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel15.setText("TREASURER");
        kGradientPanel2.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(1160, 10, -1, -1));

        candidatephoto1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        candidatephoto1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        candidatephoto1.setText("Photo");
        candidatephoto1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 3));
        kGradientPanel2.add(candidatephoto1, new org.netbeans.lib.awtextra.AbsoluteConstraints(31, 430, 190, 100));

        jTable3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTable3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable3MouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(jTable3);

        kGradientPanel2.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 540, 280, 82));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel6.setText("Your Candidate:");
        kGradientPanel2.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 630, -1, -1));

        bravo.setBackground(new java.awt.Color(102, 255, 51));
        bravo.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        bravo.setForeground(new java.awt.Color(102, 255, 51));
        bravo.setText("Vote Counted !!!");
        kGradientPanel2.add(bravo, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 170, -1, -1));

        candidatephoto3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        candidatephoto3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        candidatephoto3.setText("Photo");
        candidatephoto3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 3));
        kGradientPanel2.add(candidatephoto3, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 430, 190, 100));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        kGradientPanel2.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(8, 210, 280, 80));

        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel12.setText("Your Candidate:");
        kGradientPanel2.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 290, -1, -1));

        jTable8.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTable8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable8MouseClicked(evt);
            }
        });
        jScrollPane8.setViewportView(jTable8);

        kGradientPanel2.add(jScrollPane8, new org.netbeans.lib.awtextra.AbsoluteConstraints(1090, 210, 268, 80));

        ProtocolOfficer.setText("Vote");
        ProtocolOfficer.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        ProtocolOfficer.setkBorderRadius(60);
        ProtocolOfficer.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        ProtocolOfficer.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ProtocolOfficerMouseClicked(evt);
            }
        });
        kGradientPanel2.add(ProtocolOfficer, new org.netbeans.lib.awtextra.AbsoluteConstraints(960, 660, 59, 29));

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTable2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable2MouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(jTable2);

        kGradientPanel2.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 540, 292, 82));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setText("PRESIDENT ");
        kGradientPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 10, -1, -1));

        Secretary.setText("Vote");
        Secretary.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        Secretary.setkBorderRadius(60);
        Secretary.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        Secretary.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                SecretaryMouseClicked(evt);
            }
        });
        Secretary.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SecretaryActionPerformed(evt);
            }
        });
        kGradientPanel2.add(Secretary, new org.netbeans.lib.awtextra.AbsoluteConstraints(940, 330, 69, 25));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel5.setText("P.I.O");
        kGradientPanel2.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 390, -1, -1));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel3.setText("AUDITOR");
        kGradientPanel2.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 390, -1, -1));

        candidatephoto5.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        candidatephoto5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        candidatephoto5.setText("Photo");
        candidatephoto5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 3));
        kGradientPanel2.add(candidatephoto5, new org.netbeans.lib.awtextra.AbsoluteConstraints(770, 50, 190, 114));

        bravo1.setBackground(new java.awt.Color(102, 255, 51));
        bravo1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        bravo1.setForeground(new java.awt.Color(102, 255, 51));
        bravo1.setText("Vote Counted !!! ");
        kGradientPanel2.add(bravo1, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 480, -1, -1));

        jTable6.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTable6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable6MouseClicked(evt);
            }
        });
        jScrollPane6.setViewportView(jTable6);

        kGradientPanel2.add(jScrollPane6, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 210, 280, 82));

        candidatephoto.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        candidatephoto.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        candidatephoto.setText("Photo");
        candidatephoto.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 3));
        kGradientPanel2.add(candidatephoto, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 50, 190, 120));

        bravo3.setBackground(new java.awt.Color(102, 255, 51));
        bravo3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        bravo3.setForeground(new java.awt.Color(102, 255, 51));
        bravo3.setText("Vote Counted !!! ");
        kGradientPanel2.add(bravo3, new org.netbeans.lib.awtextra.AbsoluteConstraints(1010, 470, -1, -1));

        bravo8.setBackground(new java.awt.Color(102, 255, 51));
        bravo8.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        bravo8.setForeground(new java.awt.Color(102, 255, 51));
        bravo8.setText("Vote Counted !!! ");
        kGradientPanel2.add(bravo8, new org.netbeans.lib.awtextra.AbsoluteConstraints(1150, 180, -1, -1));

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel9.setText("VICE-PRESIDENT ");
        kGradientPanel2.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 10, 158, -1));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel2.setText("Your Candidate:");
        kGradientPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 300, -1, -1));

        jTable4.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTable4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable4MouseClicked(evt);
            }
        });
        jScrollPane4.setViewportView(jTable4);

        kGradientPanel2.add(jScrollPane4, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 540, 292, 82));

        Auditor.setText("Vote");
        Auditor.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        Auditor.setkBorderRadius(60);
        Auditor.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        Auditor.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                AuditorMouseClicked(evt);
            }
        });
        kGradientPanel2.add(Auditor, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 660, 66, 26));

        jTable5.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTable5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable5MouseClicked(evt);
            }
        });
        jScrollPane5.setViewportView(jTable5);

        kGradientPanel2.add(jScrollPane5, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 210, 292, 82));

        bravo4.setBackground(new java.awt.Color(102, 255, 51));
        bravo4.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        bravo4.setForeground(new java.awt.Color(102, 255, 51));
        bravo4.setText("Vote Counted !!! ");
        kGradientPanel2.add(bravo4, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 180, -1, -1));

        candidatephoto4.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        candidatephoto4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        candidatephoto4.setText("Photo");
        candidatephoto4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 3));
        kGradientPanel2.add(candidatephoto4, new org.netbeans.lib.awtextra.AbsoluteConstraints(376, 50, 200, 130));

        bravo7.setBackground(new java.awt.Color(102, 255, 51));
        bravo7.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        bravo7.setForeground(new java.awt.Color(102, 255, 51));
        bravo7.setText("Vote Counted !!! ");
        kGradientPanel2.add(bravo7, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 470, -1, -1));

        kGradientPanel1.setkEndColor(new java.awt.Color(0, 0, 0));
        kGradientPanel1.setkStartColor(new java.awt.Color(0, 153, 153));

        kButton1.setText("Next");
        kButton1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        kButton1.setkBorderRadius(60);
        kButton1.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        kButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                kButton1ActionPerformed(evt);
            }
        });

        jLabel13.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 255, 255));
        jLabel13.setText("Next to Proceed ");

        jLabel14.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(255, 255, 255));
        jLabel14.setText("to Another Form");

        kButton2.setText("Logout");
        kButton2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        kButton2.setkBorderRadius(60);
        kButton2.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        kButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                kButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout kGradientPanel1Layout = new javax.swing.GroupLayout(kGradientPanel1);
        kGradientPanel1.setLayout(kGradientPanel1Layout);
        kGradientPanel1Layout.setHorizontalGroup(
            kGradientPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(kGradientPanel1Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(kGradientPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel13)
                    .addGroup(kGradientPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLabel14)
                        .addGroup(kGradientPanel1Layout.createSequentialGroup()
                            .addGap(6, 6, 6)
                            .addGroup(kGradientPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(kButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(kButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addGap(23, 23, 23))
        );
        kGradientPanel1Layout.setVerticalGroup(
            kGradientPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, kGradientPanel1Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel13)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel14)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(kButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(kButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        kGradientPanel2.add(kGradientPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(1180, 410, -1, -1));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel4.setText("Your Candidate:");
        kGradientPanel2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 630, -1, -1));

        candidatephoto7.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        candidatephoto7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        candidatephoto7.setText("Photo");
        candidatephoto7.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 3));
        kGradientPanel2.add(candidatephoto7, new org.netbeans.lib.awtextra.AbsoluteConstraints(1120, 50, 190, 120));

        save.setText("Vote");
        save.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        save.setkBorderRadius(60);
        save.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        save.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                saveMouseClicked(evt);
            }
        });
        kGradientPanel2.add(save, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 330, 67, 33));

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel10.setText("Your Candidate:");
        kGradientPanel2.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(403, 290, -1, -1));

        jLabel16.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel16.setText("Your Candidate:");
        kGradientPanel2.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(1140, 290, -1, -1));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel8.setText("Your Candidate:");
        kGradientPanel2.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 630, -1, -1));

        PIO.setText("Vote");
        PIO.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        PIO.setkBorderRadius(60);
        PIO.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        PIO.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                PIOMouseClicked(evt);
            }
        });
        kGradientPanel2.add(PIO, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 660, 59, 24));
        kGradientPanel2.add(jSeparator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 40, 163, 10));
        kGradientPanel2.add(jSeparator3, new org.netbeans.lib.awtextra.AbsoluteConstraints(612, 38, 1, 10));
        kGradientPanel2.add(jSeparator5, new org.netbeans.lib.awtextra.AbsoluteConstraints(770, 40, 192, 11));
        kGradientPanel2.add(jSeparator6, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 420, 166, 10));
        kGradientPanel2.add(jSeparator7, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 420, 166, 10));
        kGradientPanel2.add(jSeparator8, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 420, 200, 10));
        kGradientPanel2.add(jSeparator9, new org.netbeans.lib.awtextra.AbsoluteConstraints(373, 38, 200, 10));

        jTextField1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        kGradientPanel2.add(jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 330, 172, -1));

        Name5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        kGradientPanel2.add(Name5, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 330, 185, -1));

        Name6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        kGradientPanel2.add(Name6, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 330, 179, -1));

        Name8.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        kGradientPanel2.add(Name8, new org.netbeans.lib.awtextra.AbsoluteConstraints(1080, 330, 173, -1));

        Name2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        kGradientPanel2.add(Name2, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 660, 168, -1));

        Name3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        kGradientPanel2.add(Name3, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 660, 161, -1));

        Name4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        kGradientPanel2.add(Name4, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 660, 160, -1));
        kGradientPanel2.add(jSeparator10, new org.netbeans.lib.awtextra.AbsoluteConstraints(1110, 40, 192, 11));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(kGradientPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(save1, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(44, 44, 44)
                .addComponent(bravo2)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(639, 639, 639)
                        .addComponent(save1, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(608, 608, 608)
                        .addComponent(bravo2)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addComponent(kGradientPanel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(1, 6, 1430, 750));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void saveMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_saveMouseClicked
        // TODO add your handling code here:
        Vcheck();
        if(key == -1|| jTextField1.getText().toString().isEmpty()){

            JOptionPane.showMessageDialog(this, "Select your Candidate ");
        }else if(vNumber > 0){
            JOptionPane.showMessageDialog(this, "You Can Not Vote Twice !!!!");
        }else
        {
            try{

                con=DriverManager.getConnection("jdbc:mysql://localhost/Moonstone","root","");
                PreparedStatement add= con.prepareStatement("INSERT INTO vote values (?,?,?,?)");
                add.setInt(1,ID);
                add.setInt(2,VotingID);
                add.setInt(3,key);
                add.setString(4, jTextField1.getText());

                int row =add.executeUpdate();
                JOptionPane.showMessageDialog(this, "vote counted");
                JOptionPane.showMessageDialog(this, "Vote Succesfully ....thank you for voting!!");
                VoteCount();
                con.close();
                bravo.setVisible(true);
                DisplayCand();
                save.setVisible(false);
            }catch(Exception ex){
                JOptionPane.showMessageDialog(this, ex);
            }
        }
    }//GEN-LAST:event_saveMouseClicked

    private void kButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_kButton1ActionPerformed
        // TODO add your handling code here:
        frame = new JFrame("Exit");
        if (JOptionPane.showConfirmDialog(this," Are you done selecting your candidate?.." ,"Voting Management System",
            JOptionPane.YES_NO_OPTION) ==JOptionPane.YES_NO_OPTION){

        new Login1().setVisible(true);
        this.dispose();
        }

        
    }//GEN-LAST:event_kButton1ActionPerformed

    private void jTable5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable5MouseClicked
        // TODO add your handling code here:
        DefaultTableModel model= (DefaultTableModel) jTable5.getModel();
        int MyIndex = jTable5.getSelectedRow();
        key = Integer.valueOf(model.getValueAt(MyIndex, 0).toString());
        Name5.setText(model.getValueAt(MyIndex, 1).toString());

        VicePhoto();
    }//GEN-LAST:event_jTable5MouseClicked
private void DisplayAuditor(){
    
    try{
     con=DriverManager.getConnection("jdbc:mysql://localhost/Moonstone","root","");
     st=con.createStatement();
     rs=st.executeQuery("Select cID,Name,Section,Position from candidate where Position = 'Auditor'");
   jTable2.setModel(DbUtils.resultSetToTableModel(rs));
     
    }catch(Exception e){
    
    
    }
    }
 private void AuditorPhoto(){
    
    String query ="Select photo from candidate where cID="+key;
    Statement st;
    ResultSet rs;
    try{
     con=DriverManager.getConnection("jdbc:mysql://localhost/Moonstone","root","");
    st=con.createStatement();
    rs=st.executeQuery(query);
    if(rs.next()){
    
    candidatephoto1.setIcon(ResizePhoto(null,rs.getBytes("Photo")));
    }
    
    }catch (Exception e){
    
    
    }
 }
  private void Vcheck4(){
        
try{
    
    st1 = con.createStatement();
    rs1 =  st1.executeQuery("Select * From Auditor Where vID="+VotingID+"");
  if (rs1.next())
  {
  
       vNumber=1;
    
  }else{
      
   vNumber=0;
  
  }

   
    }catch(Exception ex){
     JOptionPane.showMessageDialog(this, ex);
            }


   }
    private void AuditorMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_AuditorMouseClicked
        // TODO add your handling code here:
        
          Vcheck4();
        if(key == -1|| Name2.getText().toString().isEmpty()){

            JOptionPane.showMessageDialog(this, "Select your Candidate ");
        }else if(vNumber > 0){
            JOptionPane.showMessageDialog(this, "You Can Not Vote Twice !!!!");
        }else
        {
            try{

                con=DriverManager.getConnection("jdbc:mysql://localhost/Moonstone","root","");
                PreparedStatement add= con.prepareStatement("INSERT INTO Auditor values (?,?,?,?)");
                add.setInt(1,ID);
                add.setInt(2,VotingID);
                add.setInt(3,key);
                add.setString(4, Name2.getText());

                int row =add.executeUpdate();
                JOptionPane.showMessageDialog(this, "vote counted");
                JOptionPane.showMessageDialog(this, "Vote Succesfully ....thank you for voting!!");
                VoteCount();
                con.close();
               bravo1.setVisible(true);
              DisplayAuditor();
                Auditor.setVisible(false);
            }catch(Exception ex){
                JOptionPane.showMessageDialog(this, ex);
            }
        }

        
    }//GEN-LAST:event_AuditorMouseClicked

    private void jTable4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable4MouseClicked
        // TODO add your handling code here:
          DefaultTableModel model= (DefaultTableModel) jTable4.getModel();
        int MyIndex = jTable4.getSelectedRow();
        key = Integer.valueOf(model.getValueAt(MyIndex, 0).toString());
        Name4.setText(model.getValueAt(MyIndex, 1).toString());
       ProtocolOfficerPhoto();
    }//GEN-LAST:event_jTable4MouseClicked

    private void jTable6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable6MouseClicked
        // TODO add your handling code here:
      
         DefaultTableModel model= (DefaultTableModel) jTable6.getModel();
        int MyIndex = jTable6.getSelectedRow();
        key = Integer.valueOf(model.getValueAt(MyIndex, 0).toString());
        Name6.setText(model.getValueAt(MyIndex, 1).toString());
        SecretaryPhoto();
    }//GEN-LAST:event_jTable6MouseClicked
private void DisplaySecretary(){
    
    try{
     con=DriverManager.getConnection("jdbc:mysql://localhost/Moonstone","root","");
     st=con.createStatement();
     rs=st.executeQuery("Select cID,Name,Section,Position from candidate where Position = 'Secretary'");
   jTable6.setModel(DbUtils.resultSetToTableModel(rs));
     
    }catch(Exception e){
    
    
    }
    }
 private void SecretaryPhoto(){
    
    String query ="Select photo from candidate where cID="+key;
    Statement st;
    ResultSet rs;
    try{
     con=DriverManager.getConnection("jdbc:mysql://localhost/Moonstone","root","");
    st=con.createStatement();
    rs=st.executeQuery(query);
    if(rs.next()){
    
    candidatephoto5.setIcon(ResizePhoto(null,rs.getBytes("Photo")));
    }
    
    }catch (Exception e){
    
    
    }
 }
   private void Vcheck2(){
        
try{
    
    st1 = con.createStatement();
    rs1 =  st1.executeQuery("Select * From Secretary Where vID="+VotingID+"");
  if (rs1.next())
  {
  
       vNumber=1;
    
  }else{
      
   vNumber=0;
  
  }

   
    }catch(Exception ex){
     JOptionPane.showMessageDialog(this, ex);
            }


   }
 
    private void SecretaryMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SecretaryMouseClicked
        // TODO add your handling code here:
        
         Vcheck2();
        if(key == -1|| Name6.getText().toString().isEmpty()){

            JOptionPane.showMessageDialog(this, "Select your Candidate ");
        }else if(vNumber > 0){
            JOptionPane.showMessageDialog(this, "You Can Not Vote Twice !!!!");
        }else
        {
            try{

                con=DriverManager.getConnection("jdbc:mysql://localhost/Moonstone","root","");
                PreparedStatement add= con.prepareStatement("INSERT INTO Secretary values (?,?,?,?)");
                add.setInt(1,ID);
                add.setInt(2,VotingID);
                add.setInt(3,key);
                add.setString(4, Name6.getText());

                int row =add.executeUpdate();
                JOptionPane.showMessageDialog(this, "vote counted");
                JOptionPane.showMessageDialog(this, "Vote Succesfully ....thank you for voting!!");
                VoteCount();
                con.close();
                bravo5.setVisible(true);
               DisplaySecretary();
                Secretary.setVisible(false);
            }catch(Exception ex){
                JOptionPane.showMessageDialog(this, ex);
            }
        }
  
    }//GEN-LAST:event_SecretaryMouseClicked

    private void jTable2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable2MouseClicked
        // TODO add your handling code here:
          DefaultTableModel model= (DefaultTableModel) jTable2.getModel();
        int MyIndex = jTable2.getSelectedRow();
        key = Integer.valueOf(model.getValueAt(MyIndex, 0).toString());
        Name2.setText(model.getValueAt(MyIndex, 1).toString());
        AuditorPhoto();
    }//GEN-LAST:event_jTable2MouseClicked
private void DisplayProtocolOfficer(){
    
    try{
     con=DriverManager.getConnection("jdbc:mysql://localhost/Moonstone","root","");
     st=con.createStatement();
     rs=st.executeQuery("Select cID,Name,Section,Position from candidate where Position = 'Protocol Officer'");
   jTable4.setModel(DbUtils.resultSetToTableModel(rs));
     
    }catch(Exception e){
    
    
    }
    }
 private void ProtocolOfficerPhoto(){
    
    String query ="Select photo from candidate where cID="+key;
    Statement st;
    ResultSet rs;
    try{
     con=DriverManager.getConnection("jdbc:mysql://localhost/Moonstone","root","");
    st=con.createStatement();
    rs=st.executeQuery(query);
    if(rs.next()){
    
    candidatephoto3.setIcon(ResizePhoto(null,rs.getBytes("Photo")));
    }
    
    }catch (Exception e){
    
    
    }
 }
  private void Vcheck6(){
        
try{
    
    st1 = con.createStatement();
    rs1 =  st1.executeQuery("Select * From ProtocolOfficer Where vID="+VotingID+"");
  if (rs1.next())
  {
  
       vNumber=1;
    
  }else{
      
   vNumber=0;
  
  }

   
    }catch(Exception ex){
     JOptionPane.showMessageDialog(this, ex);
            }


   }
    private void ProtocolOfficerMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ProtocolOfficerMouseClicked
        // TODO add your handling code here:
        Vcheck6();
         if(key == -1|| Name4.getText().toString().isEmpty()){

            JOptionPane.showMessageDialog(this, "Select your Candidate ");
        }else if(vNumber > 0){
            JOptionPane.showMessageDialog(this, "You Can Not Vote Twice !!!!");
        }else
        {
            try{

                con=DriverManager.getConnection("jdbc:mysql://localhost/Moonstone","root","");
                PreparedStatement add= con.prepareStatement("INSERT INTO ProtocolOfficer values (?,?,?,?)");
                add.setInt(1,ID);
                add.setInt(2,VotingID);
                add.setInt(3,key);
                add.setString(4, Name4.getText());

                int row =add.executeUpdate();
                JOptionPane.showMessageDialog(this, "vote counted");
                JOptionPane.showMessageDialog(this, "Vote Succesfully ....thank you for voting!!");
                VoteCount();
                con.close();
                bravo3.setVisible(true);
              DisplayProtocolOfficer();
                ProtocolOfficer.setVisible(false);
            }catch(Exception ex){
                JOptionPane.showMessageDialog(this, ex);
            }
        }
        
        
    }//GEN-LAST:event_ProtocolOfficerMouseClicked

    private void jTable8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable8MouseClicked
        // TODO add your handling code here:
          DefaultTableModel model= (DefaultTableModel) jTable8.getModel();
        int MyIndex = jTable8.getSelectedRow();
        key = Integer.valueOf(model.getValueAt(MyIndex, 0).toString());
        Name8.setText(model.getValueAt(MyIndex, 1).toString());
        TreasurerrPhoto();
    }//GEN-LAST:event_jTable8MouseClicked

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        // TODO add your handling code here:
        DefaultTableModel model= (DefaultTableModel) jTable1.getModel();
        int MyIndex = jTable1.getSelectedRow();
        key = Integer.valueOf(model.getValueAt(MyIndex, 0).toString());
        jTextField1.setText(model.getValueAt(MyIndex, 1).toString());

        FetchPhoto();
    }//GEN-LAST:event_jTable1MouseClicked

    private void jTable3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable3MouseClicked
        // TODO add your handling code here:
          DefaultTableModel model= (DefaultTableModel) jTable3.getModel();
        int MyIndex = jTable3.getSelectedRow();
        key = Integer.valueOf(model.getValueAt(MyIndex, 0).toString());
        Name3.setText(model.getValueAt(MyIndex, 1).toString());

        PIOPhoto();
        
    }//GEN-LAST:event_jTable3MouseClicked
private void DisplayTreasurer(){
    
    try{
     con=DriverManager.getConnection("jdbc:mysql://localhost/Moonstone","root","");
     st=con.createStatement();
     rs=st.executeQuery("Select cID,Name,Section,Position from candidate where Position = 'Treasurer'");
   jTable8.setModel(DbUtils.resultSetToTableModel(rs));
     
    }catch(Exception e){
    
    
    }
    }
 private void TreasurerrPhoto(){
    
    String query ="Select photo from candidate where cID="+key;
    Statement st;
    ResultSet rs;
    try{
     con=DriverManager.getConnection("jdbc:mysql://localhost/Moonstone","root","");
    st=con.createStatement();
    rs=st.executeQuery(query);
    if(rs.next()){
    
    candidatephoto7.setIcon(ResizePhoto(null,rs.getBytes("Photo")));
    }
    
    }catch (Exception e){
    
    
    }
 }
  private void Vcheck3(){
        
try{
    
    st1 = con.createStatement();
    rs1 =  st1.executeQuery("Select * From Treasurer Where vID="+VotingID+"");
  if (rs1.next())
  {
  
       vNumber=1;
    
  }else{
      
   vNumber=0;
  
  }

   
    }catch(Exception ex){
     JOptionPane.showMessageDialog(this, ex);
            }


   }
    private void treasurerMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_treasurerMouseClicked
        // TODO add your handling code here:
         Vcheck3();
        if(key == -1|| Name8.getText().toString().isEmpty()){

            JOptionPane.showMessageDialog(this, "Select your Candidate ");
        }else if(vNumber > 0){
            JOptionPane.showMessageDialog(this, "You Can Not Vote Twice !!!!");
        }else
        {
            try{

                con=DriverManager.getConnection("jdbc:mysql://localhost/Moonstone","root","");
                PreparedStatement add= con.prepareStatement("INSERT INTO treasurer values (?,?,?,?)");
                add.setInt(1,ID);
                add.setInt(2,VotingID);
                add.setInt(3,key);
                add.setString(4, Name8.getText());

                int row =add.executeUpdate();
                JOptionPane.showMessageDialog(this, "vote counted");
                JOptionPane.showMessageDialog(this, "Vote Succesfully ....thank you for voting!!");
                VoteCount();
                con.close();
              bravo8.setVisible(true);
              DisplayTreasurer();
                treasurer.setVisible(false);
            }catch(Exception ex){
                JOptionPane.showMessageDialog(this, ex);
            }
        }
    }//GEN-LAST:event_treasurerMouseClicked
  
          private void Vpcheck(){
        
try{
    
    st1 = con.createStatement();
    rs1 =  st1.executeQuery("Select * From vicepres Where vID="+VotingID+"");
  if (rs1.next())
  {
  
       vNumber=1;
    
  }else{
      
   vNumber=0;
  
  }

   
    }catch(Exception ex){
     JOptionPane.showMessageDialog(this, ex);
            }
          }


    private void btnVPMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnVPMouseClicked
        // TODO add your handling code here:
        Vpcheck();
        if(key == -1|| Name5.getText().toString().isEmpty()){

            JOptionPane.showMessageDialog(this, "Select your Candidate ");
        }else if(vNumber > 0){
            JOptionPane.showMessageDialog(this, "You Can Not Vote Twice !!!!");
        }else
        {
            try{

                con=DriverManager.getConnection("jdbc:mysql://localhost/Moonstone","root","");
                PreparedStatement add= con.prepareStatement("INSERT INTO vicepres values (?,?,?,?)");
                add.setInt(1,ID);
                add.setInt(2,VotingID);
                add.setInt(3,key);
                add.setString(4, Name5.getText());

                int row =add.executeUpdate();
                JOptionPane.showMessageDialog(this, "vote counted");
                JOptionPane.showMessageDialog(this, "Vote Succesfully ....thank you for voting!!");
                VoteCount();
                con.close();
                bravo4.setVisible(true);
                DisplayVice();
                btnVP.setVisible(false);
            }catch(Exception ex){
                JOptionPane.showMessageDialog(this, ex);
            }
        }

    }//GEN-LAST:event_btnVPMouseClicked

    private void save1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_save1MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_save1MouseClicked
private void DisplayPIO(){
    
    try{
     con=DriverManager.getConnection("jdbc:mysql://localhost/Moonstone","root","");
     st=con.createStatement();
     rs=st.executeQuery("Select cID,Name,Section,Position from candidate where Position = 'P.I.O'");
   jTable3.setModel(DbUtils.resultSetToTableModel(rs));
     
    }catch(Exception e){
    
    
    }
    }
 private void PIOPhoto(){
    
    String query ="Select photo from candidate where cID="+key;
    Statement st;
    ResultSet rs;
    try{
     con=DriverManager.getConnection("jdbc:mysql://localhost/Moonstone","root","");
    st=con.createStatement();
    rs=st.executeQuery(query);
    if(rs.next()){
    
    candidatephoto2.setIcon(ResizePhoto(null,rs.getBytes("Photo")));
    }
    
    }catch (Exception e){
    
    
    }
 }
  private void Vcheck5(){
        
try{
    
    st1 = con.createStatement();
    rs1 =  st1.executeQuery("Select * From pio Where vID="+VotingID+"");
  if (rs1.next())
  {
  
       vNumber=1;
    
  }else{
      
   vNumber=0;
  
  }

   
    }catch(Exception ex){
     JOptionPane.showMessageDialog(this, ex);
            }


   }
    private void PIOMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PIOMouseClicked
        // TODO add your handling code here:
         Vcheck5();
        if(key == -1|| Name3.getText().toString().isEmpty()){

            JOptionPane.showMessageDialog(this, "Select your Candidate ");
        }else if(vNumber > 0){
            JOptionPane.showMessageDialog(this, "You Can Not Vote Twice !!!!");
        }else
        {
            try{

                con=DriverManager.getConnection("jdbc:mysql://localhost/Moonstone","root","");
                PreparedStatement add= con.prepareStatement("INSERT INTO pio values (?,?,?,?)");
                add.setInt(1,ID);
                add.setInt(2,VotingID);
                add.setInt(3,key);
                add.setString(4, Name3.getText());

                int row =add.executeUpdate();
                JOptionPane.showMessageDialog(this, "vote counted");
                JOptionPane.showMessageDialog(this, "Vote Succesfully ....thank you for voting!!");
                VoteCount();
                con.close();
               bravo7.setVisible(true);
             DisplayPIO();
                PIO.setVisible(false);
            }catch(Exception ex){
                JOptionPane.showMessageDialog(this, ex);
            }
        }

        
        
    }//GEN-LAST:event_PIOMouseClicked

    private void kButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_kButton2ActionPerformed
        // TODO add your handling code here:
         frame = new JFrame("Exit");
        if (JOptionPane.showConfirmDialog(this," Do you want to exit?.." ,"Voting Management System",
            JOptionPane.YES_NO_OPTION) ==JOptionPane.YES_NO_OPTION){

        new Login().setVisible(true);
        this.dispose();
        }
    }//GEN-LAST:event_kButton2ActionPerformed

    private void SecretaryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SecretaryActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_SecretaryActionPerformed

    private void treasurerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_treasurerActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_treasurerActionPerformed
 int key = -1;
     int ID;
    Statement st1 = null;
    ResultSet rs1= null;
    private void VoteCount(){
        
try{
    
    st1 = con.createStatement();
    rs1 =  st1.executeQuery("Select MAx (ID) From vote");
    rs1.next();
    ID = rs1.getInt(1)+ 1;
    }catch(Exception ex){
            
            }


}
    int vNumber;
     private void Vcheck(){
        
try{
    
    st1 = con.createStatement();
    rs1 =  st1.executeQuery("Select * From vote Where vID="+VotingID+"");
  if (rs1.next())
  {
  
       vNumber=1;
    
  }else{
      
   vNumber=0;
  
  }

   
    }catch(Exception ex){
     JOptionPane.showMessageDialog(this, ex);
            }


}private ImageIcon ResizePhoto(String ImagePath, byte[] pic)
 {
 
 
     ImageIcon MyImage = null;
     
     if(ImagePath != null)
     {
 
     MyImage = new ImageIcon(ImagePath);
     } else
     
     {
         MyImage =  new ImageIcon(pic);
         }
 Image img = MyImage.getImage();
 Image newimg= img.getScaledInstance(candidatephoto.getWidth(), candidatephoto.getHeight(),Image.SCALE_SMOOTH);
 ImageIcon image=new ImageIcon(newimg);
         return image;
 }
    
    
    String imgpath=null;
private void DisplayVice(){
    
    try{
     con=DriverManager.getConnection("jdbc:mysql://localhost/Moonstone","root","");
     st=con.createStatement();
     rs=st.executeQuery("Select cID,Name,Section,Position from candidate where Position = 'Vice-President'");
   jTable5.setModel(DbUtils.resultSetToTableModel(rs));
     
    }catch(Exception e){
    
    
    }
    }
 private void VicePhoto(){
    
    String query ="Select photo from candidate where cID="+key;
    Statement st;
    ResultSet rs;
    try{
     con=DriverManager.getConnection("jdbc:mysql://localhost/Moonstone","root","");
    st=con.createStatement();
    rs=st.executeQuery(query);
    if(rs.next()){
    
    candidatephoto4.setIcon(ResizePhoto(null,rs.getBytes("Photo")));
    }
    
    }catch (Exception e){
    
    
    }
    }private JFrame frame;
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(voter_dashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(voter_dashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(voter_dashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(voter_dashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new voter_dashboard().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private com.k33ptoo.components.KButton Auditor;
    private javax.swing.JTextField Name2;
    private javax.swing.JTextField Name3;
    private javax.swing.JTextField Name4;
    private javax.swing.JTextField Name5;
    private javax.swing.JTextField Name6;
    private javax.swing.JTextField Name8;
    private com.k33ptoo.components.KButton PIO;
    private com.k33ptoo.components.KButton ProtocolOfficer;
    private com.k33ptoo.components.KButton Secretary;
    private javax.swing.JLabel bravo;
    private javax.swing.JLabel bravo1;
    private javax.swing.JLabel bravo2;
    private javax.swing.JLabel bravo3;
    private javax.swing.JLabel bravo4;
    private javax.swing.JLabel bravo5;
    private javax.swing.JLabel bravo7;
    private javax.swing.JLabel bravo8;
    private com.k33ptoo.components.KButton btnVP;
    private javax.swing.JLabel candidatephoto;
    private javax.swing.JLabel candidatephoto1;
    private javax.swing.JLabel candidatephoto2;
    private javax.swing.JLabel candidatephoto3;
    private javax.swing.JLabel candidatephoto4;
    private javax.swing.JLabel candidatephoto5;
    private javax.swing.JLabel candidatephoto7;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator10;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator5;
    private javax.swing.JSeparator jSeparator6;
    private javax.swing.JSeparator jSeparator7;
    private javax.swing.JSeparator jSeparator8;
    private javax.swing.JSeparator jSeparator9;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTable jTable3;
    private javax.swing.JTable jTable4;
    private javax.swing.JTable jTable5;
    private javax.swing.JTable jTable6;
    private javax.swing.JTable jTable8;
    private javax.swing.JTextField jTextField1;
    private com.k33ptoo.components.KButton kButton1;
    private com.k33ptoo.components.KButton kButton2;
    private com.k33ptoo.components.KGradientPanel kGradientPanel1;
    private com.k33ptoo.components.KGradientPanel kGradientPanel2;
    private com.k33ptoo.components.KButton save;
    private com.k33ptoo.components.KButton save1;
    private com.k33ptoo.components.KButton treasurer;
    // End of variables declaration//GEN-END:variables
}
