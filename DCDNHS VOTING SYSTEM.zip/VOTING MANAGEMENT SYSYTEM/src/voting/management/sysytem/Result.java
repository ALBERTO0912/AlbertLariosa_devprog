/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JInternalFrame.java to edit this template
 */
package voting.management.sysytem;

import java.awt.Image;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DecimalFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.plaf.basic.BasicInternalFrameUI;
import javax.swing.table.DefaultTableModel;
import net.proteanit.sql.DbUtils;


public class Result extends javax.swing.JInternalFrame {

   
    public Result() {
        initComponents();
           this.setBorder(javax.swing.BorderFactory.createEmptyBorder(0,0,0,0));
        BasicInternalFrameUI ui=(BasicInternalFrameUI)this.getUI();
        ui.setNorthPane(null);
      DisplayCand();
      DisplayVice();
      DisplaySec();
       DisplayTreasurer();
       DisplayAuditor();
       DisplayPIO();
       DisplayOfficer();
    }

  Connection con= null;
PreparedStatement pst= null;
ResultSet rs = null;
Statement st = null;

     private void DisplayCand(){
    
    try{
     con=DriverManager.getConnection("jdbc:mysql://localhost/Moonstone","root","");
     st=con.createStatement();
     rs=st.executeQuery(" Select cID,Name,Photo from candidate where Position = 'President'");
   Pres.setModel(DbUtils.resultSetToTableModel(rs));
     
    }catch(Exception e){
    
    
    }
    }
     private void FetchPhoto(){
    
    String query ="Select photo from candidate where cID="+key;
    Statement st;
    ResultSet rs;
    try{
     con=DriverManager.getConnection("jdbc:mysql://localhost/Moonstone","root","");
    st=con.createStatement();
    rs=st.executeQuery(query);
    if(rs.next()){
    
    candidatephoto.setIcon(ResizePhoto(null,rs.getBytes("Photo")));
    }
    
    }catch (Exception e){
    
    
    }
    }
    
     
     private ImageIcon ResizePhoto(String ImagePath, byte[] pic)
 {
 
 
     ImageIcon MyImage = null;
     
     if(ImagePath != null)
     {
 
     MyImage = new ImageIcon(ImagePath);
     } else
     
     {
         MyImage =  new ImageIcon(pic);
         }
 Image img = MyImage.getImage();
 Image newimg= img.getScaledInstance(candidatephoto.getWidth(), candidatephoto.getHeight(),Image.SCALE_SMOOTH);
 ImageIcon image=new ImageIcon(newimg);
         return image;
 }
    
       int WinnerID,Votes;
    private void GetWinner(){
    
    
    try{    
        con=DriverManager.getConnection("jdbc:mysql://localhost/Moonstone","root","");
        st=con.createStatement();
      String Query = "Select cID, Count(cID) From vote Where cID="+key+" Group By cID ORDER BY cID DESC LIMIT 1";
      rs = st.executeQuery(Query);
      while(rs.next()){
     //  JOptionPane.showMessageDialog(this,""+Votes);
       WinnerID=rs.getInt(1);
      }
      
    }catch(Exception e){
    JOptionPane.showMessageDialog(this,e);
    }
}
     private void GetVote(){
     
    
     try{    
        con=DriverManager.getConnection("jdbc:mysql://localhost/Moonstone","root","");
        st=con.createStatement();
  String Query = "Select Count(cID) From vote Where cID="+WinnerID;
      rs = st.executeQuery(Query);
      while(rs.next()){
      // JOptionPane.showMessageDialog(this,""+Votes));
       Votes=rs.getInt(1);
       Count.setText(Votes+ " Votes");
      }
      
    }catch(Exception e){
    JOptionPane.showMessageDialog(this,e);
    }
    }
     
  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        Pres = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        Name = new javax.swing.JLabel();
        candidatephoto = new javax.swing.JLabel();
        Counts = new javax.swing.JLabel();
        Count1 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        VicePres = new javax.swing.JTable();
        Counts1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        President = new javax.swing.JLabel();
        candidatephoto1 = new javax.swing.JLabel();
        Count = new javax.swing.JLabel();
        Name2 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jSeparator2 = new javax.swing.JSeparator();
        President1 = new javax.swing.JLabel();
        jSeparator3 = new javax.swing.JSeparator();
        candidatephoto2 = new javax.swing.JLabel();
        President2 = new javax.swing.JLabel();
        jSeparator4 = new javax.swing.JSeparator();
        jLabel4 = new javax.swing.JLabel();
        Name3 = new javax.swing.JLabel();
        Counts2 = new javax.swing.JLabel();
        Count2 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        Sec = new javax.swing.JTable();
        jScrollPane4 = new javax.swing.JScrollPane();
        Treasurer = new javax.swing.JTable();
        Counts3 = new javax.swing.JLabel();
        Count3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        Name4 = new javax.swing.JLabel();
        candidatephoto3 = new javax.swing.JLabel();
        President3 = new javax.swing.JLabel();
        jSeparator5 = new javax.swing.JSeparator();
        President4 = new javax.swing.JLabel();
        jSeparator6 = new javax.swing.JSeparator();
        candidatephoto4 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        Counts4 = new javax.swing.JLabel();
        Count4 = new javax.swing.JLabel();
        Name5 = new javax.swing.JLabel();
        jScrollPane5 = new javax.swing.JScrollPane();
        Auditor = new javax.swing.JTable();
        President5 = new javax.swing.JLabel();
        jSeparator7 = new javax.swing.JSeparator();
        candidatephoto5 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        Counts5 = new javax.swing.JLabel();
        Count5 = new javax.swing.JLabel();
        Name6 = new javax.swing.JLabel();
        jScrollPane6 = new javax.swing.JScrollPane();
        PIO = new javax.swing.JTable();
        President6 = new javax.swing.JLabel();
        jSeparator8 = new javax.swing.JSeparator();
        candidatephoto6 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        Name7 = new javax.swing.JLabel();
        Counts6 = new javax.swing.JLabel();
        Count6 = new javax.swing.JLabel();
        jScrollPane7 = new javax.swing.JScrollPane();
        Officer = new javax.swing.JTable();
        jSeparator9 = new javax.swing.JSeparator();

        setPreferredSize(new java.awt.Dimension(1100, 700));

        jPanel1.setBackground(new java.awt.Color(0, 153, 153));
        jPanel1.setPreferredSize(new java.awt.Dimension(1130, 760));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Pres.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        Pres.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                PresMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(Pres);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 220, 250, 80));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel2.setText("Name of Candidate:");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 160, 175, -1));

        Name.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        Name.setForeground(new java.awt.Color(255, 255, 255));
        Name.setText("Name");
        jPanel1.add(Name, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 160, 150, -1));

        candidatephoto.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        candidatephoto.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        candidatephoto.setText("Photo");
        jPanel1.add(candidatephoto, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 60, 140, 90));

        Counts.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        Counts.setForeground(new java.awt.Color(255, 255, 255));
        Counts.setText("Result Count :");
        jPanel1.add(Counts, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 190, 123, -1));

        Count1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        Count1.setForeground(new java.awt.Color(255, 255, 255));
        Count1.setText("0");
        jPanel1.add(Count1, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 190, -1, -1));

        VicePres.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        VicePres.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                VicePresMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(VicePres);

        jPanel1.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 220, 250, 80));

        Counts1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        Counts1.setForeground(new java.awt.Color(255, 255, 255));
        Counts1.setText("Result Count :");
        jPanel1.add(Counts1, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 190, 123, -1));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel3.setText("Name of Candidate:");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 160, 175, -1));

        President.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        President.setForeground(new java.awt.Color(255, 255, 255));
        President.setText("President");
        jPanel1.add(President, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 20, 90, -1));

        candidatephoto1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        candidatephoto1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        candidatephoto1.setText("Photo");
        jPanel1.add(candidatephoto1, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 50, 140, 100));

        Count.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        Count.setForeground(new java.awt.Color(255, 255, 255));
        Count.setText("0");
        jPanel1.add(Count, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 190, -1, -1));

        Name2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        Name2.setForeground(new java.awt.Color(255, 255, 255));
        Name2.setText("Name");
        jPanel1.add(Name2, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 160, 150, -1));
        jPanel1.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 50, -1, -1));
        jPanel1.add(jSeparator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 50, 160, 10));

        President1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        President1.setForeground(new java.awt.Color(255, 255, 255));
        President1.setText("Vice-President");
        jPanel1.add(President1, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 10, 140, -1));
        jPanel1.add(jSeparator3, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 40, 170, 10));

        candidatephoto2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        candidatephoto2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        candidatephoto2.setText("Photo");
        jPanel1.add(candidatephoto2, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 50, 130, 100));

        President2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        President2.setForeground(new java.awt.Color(255, 255, 255));
        President2.setText("Secretary");
        jPanel1.add(President2, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 10, 90, -1));
        jPanel1.add(jSeparator4, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 40, 170, 10));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel4.setText("Name of Candidate:");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 160, 175, -1));

        Name3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        Name3.setForeground(new java.awt.Color(255, 255, 255));
        Name3.setText("Name");
        jPanel1.add(Name3, new org.netbeans.lib.awtextra.AbsoluteConstraints(950, 160, 140, -1));

        Counts2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        Counts2.setForeground(new java.awt.Color(255, 255, 255));
        Counts2.setText("Result Count :");
        jPanel1.add(Counts2, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 190, 123, -1));

        Count2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        Count2.setForeground(new java.awt.Color(255, 255, 255));
        Count2.setText("0");
        jPanel1.add(Count2, new org.netbeans.lib.awtextra.AbsoluteConstraints(900, 190, -1, -1));

        Sec.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        Sec.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                SecMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(Sec);

        jPanel1.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 220, 250, 80));

        Treasurer.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        Treasurer.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TreasurerMouseClicked(evt);
            }
        });
        jScrollPane4.setViewportView(Treasurer);

        jPanel1.add(jScrollPane4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 580, 250, 80));

        Counts3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        Counts3.setForeground(new java.awt.Color(255, 255, 255));
        Counts3.setText("Result Count :");
        jPanel1.add(Counts3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 540, 123, -1));

        Count3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        Count3.setForeground(new java.awt.Color(255, 255, 255));
        Count3.setText("0");
        jPanel1.add(Count3, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 540, -1, -1));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel5.setText("Name of Candidate:");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 480, 175, -1));

        Name4.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        Name4.setForeground(new java.awt.Color(255, 255, 255));
        Name4.setText("Name");
        jPanel1.add(Name4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 510, 270, -1));

        candidatephoto3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        candidatephoto3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        candidatephoto3.setText("Photo");
        jPanel1.add(candidatephoto3, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 370, 130, 100));

        President3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        President3.setForeground(new java.awt.Color(255, 255, 255));
        President3.setText("Treasurer");
        jPanel1.add(President3, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 330, 90, -1));
        jPanel1.add(jSeparator5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 360, 170, 10));

        President4.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        President4.setForeground(new java.awt.Color(255, 255, 255));
        President4.setText("Auditor");
        jPanel1.add(President4, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 330, 90, -1));
        jPanel1.add(jSeparator6, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 360, 170, 10));

        candidatephoto4.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        candidatephoto4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        candidatephoto4.setText("Photo");
        jPanel1.add(candidatephoto4, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 370, 130, 100));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel6.setText("Name of Candidate:");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 480, 175, -1));

        Counts4.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        Counts4.setForeground(new java.awt.Color(255, 255, 255));
        Counts4.setText("Result Count :");
        jPanel1.add(Counts4, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 540, 123, -1));

        Count4.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        Count4.setForeground(new java.awt.Color(255, 255, 255));
        Count4.setText("0");
        jPanel1.add(Count4, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 540, -1, -1));

        Name5.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        Name5.setForeground(new java.awt.Color(255, 255, 255));
        Name5.setText("Name");
        jPanel1.add(Name5, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 510, 210, -1));

        Auditor.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        Auditor.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                AuditorMouseClicked(evt);
            }
        });
        jScrollPane5.setViewportView(Auditor);

        jPanel1.add(jScrollPane5, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 580, 250, 80));

        President5.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        President5.setForeground(new java.awt.Color(255, 255, 255));
        President5.setText("P.I.O");
        jPanel1.add(President5, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 330, 80, -1));
        jPanel1.add(jSeparator7, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 360, 170, 10));

        candidatephoto5.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        candidatephoto5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        candidatephoto5.setText("Photo");
        jPanel1.add(candidatephoto5, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 370, 130, 100));

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel7.setText("Name of Candidate:");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 480, 175, -1));

        Counts5.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        Counts5.setForeground(new java.awt.Color(255, 255, 255));
        Counts5.setText("Result Count :");
        jPanel1.add(Counts5, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 540, 123, -1));

        Count5.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        Count5.setForeground(new java.awt.Color(255, 255, 255));
        Count5.setText("0");
        jPanel1.add(Count5, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 540, -1, -1));

        Name6.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        Name6.setForeground(new java.awt.Color(255, 255, 255));
        Name6.setText("Name");
        jPanel1.add(Name6, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 510, 220, -1));

        PIO.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        PIO.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                PIOMouseClicked(evt);
            }
        });
        jScrollPane6.setViewportView(PIO);

        jPanel1.add(jScrollPane6, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 580, 250, 80));

        President6.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        President6.setForeground(new java.awt.Color(255, 255, 255));
        President6.setText("Protocol Officer");
        jPanel1.add(President6, new org.netbeans.lib.awtextra.AbsoluteConstraints(870, 330, 150, -1));
        jPanel1.add(jSeparator8, new org.netbeans.lib.awtextra.AbsoluteConstraints(860, 360, 170, 10));

        candidatephoto6.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        candidatephoto6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        candidatephoto6.setText("Photo");
        jPanel1.add(candidatephoto6, new org.netbeans.lib.awtextra.AbsoluteConstraints(870, 370, 130, 100));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel8.setText("Name of Candidate:");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(840, 480, 175, -1));

        Name7.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        Name7.setForeground(new java.awt.Color(255, 255, 255));
        Name7.setText("Name");
        jPanel1.add(Name7, new org.netbeans.lib.awtextra.AbsoluteConstraints(840, 510, 220, -1));

        Counts6.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        Counts6.setForeground(new java.awt.Color(255, 255, 255));
        Counts6.setText("Result Count :");
        jPanel1.add(Counts6, new org.netbeans.lib.awtextra.AbsoluteConstraints(840, 540, 123, -1));

        Count6.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        Count6.setForeground(new java.awt.Color(255, 255, 255));
        Count6.setText("0");
        jPanel1.add(Count6, new org.netbeans.lib.awtextra.AbsoluteConstraints(980, 540, -1, -1));

        Officer.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        Officer.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                OfficerMouseClicked(evt);
            }
        });
        jScrollPane7.setViewportView(Officer);

        jPanel1.add(jScrollPane7, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 580, 250, 80));
        jPanel1.add(jSeparator9, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 313, 1050, 10));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 1109, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 710, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
 
    int key = -1;
     
    private void PresMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PresMouseClicked
        // TODO add your handling code here:
         DefaultTableModel model= (DefaultTableModel) Pres.getModel();
        int MyIndex = Pres.getSelectedRow();
        key = Integer.valueOf(model.getValueAt(MyIndex, 0).toString());
         Name.setText(model.getValueAt(MyIndex, 1).toString());
        Count.setText(model.getValueAt(MyIndex, 2).toString());
      
       FetchPhoto();
        GetWinner();
        GetVote();
     
    }//GEN-LAST:event_PresMouseClicked
 private void DisplayVice(){
    
    try{
     con=DriverManager.getConnection("jdbc:mysql://localhost/Moonstone","root","");
     st=con.createStatement();
     rs=st.executeQuery(" Select cID,Name,Photo from candidate where Position = 'Vice-President'");
   VicePres.setModel(DbUtils.resultSetToTableModel(rs));
     
    }catch(Exception e){
    
    
    }
    }
   int WinnerID1,Votes1;
   private void GetWinner1(){
    
    
    try{    
        con=DriverManager.getConnection("jdbc:mysql://localhost/Moonstone","root","");
        st=con.createStatement();
      String Query = "Select cID, Count(cID) From vicepres Where cID="+key+" Group By cID ORDER BY cID DESC LIMIT 1";
      rs = st.executeQuery(Query);
      while(rs.next()){
     //  JOptionPane.showMessageDialog(this,""+Votes);
       WinnerID1=rs.getInt(1);
      }
      
    }catch(Exception e){
    JOptionPane.showMessageDialog(this,e);
    }
}
     private void GetVote1(){
     
    
     try{    
        con=DriverManager.getConnection("jdbc:mysql://localhost/Moonstone","root","");
        st=con.createStatement();
  String Query = "Select Count(cID) From vicepres Where cID="+WinnerID1;
      rs = st.executeQuery(Query);
      while(rs.next()){
      // JOptionPane.showMessageDialog(this,""+Votes));
       Votes1=rs.getInt(1);
       Count1.setText(Votes1+ " Votes");
      }
      
    }catch(Exception e){
    JOptionPane.showMessageDialog(this,e);
    }
    }
  
     
     private void vicePhoto(){
    
    String query ="Select photo from candidate where cID="+key;
    Statement st;
    ResultSet rs;
    try{
     con=DriverManager.getConnection("jdbc:mysql://localhost/Moonstone","root","");
    st=con.createStatement();
    rs=st.executeQuery(query);
    if(rs.next()){
    
    candidatephoto1.setIcon(ResizePhoto(null,rs.getBytes("Photo")));
    }
    
    }catch (Exception e){
    
    
    }
    }
    
  
    private void VicePresMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_VicePresMouseClicked
        // TODO add your handling code here:
          DefaultTableModel model= (DefaultTableModel) VicePres.getModel();
        int MyIndex = VicePres.getSelectedRow();
        key = Integer.valueOf(model.getValueAt(MyIndex, 0).toString());
         Name2.setText(model.getValueAt(MyIndex, 1).toString());
        Count1.setText(model.getValueAt(MyIndex, 2).toString());
      
       vicePhoto();
     GetWinner1();
     GetVote1();
    }//GEN-LAST:event_VicePresMouseClicked
private void DisplaySec(){
    
    try{
     con=DriverManager.getConnection("jdbc:mysql://localhost/Moonstone","root","");
     st=con.createStatement();
     rs=st.executeQuery(" Select cID,Name,Photo from candidate where Position = 'Secretary'");
   Sec.setModel(DbUtils.resultSetToTableModel(rs));
     
    }catch(Exception e){
    
    
    }
    }
   int WinnerID2,Votes2;
   private void GetWinner2(){
    
    
    try{    
        con=DriverManager.getConnection("jdbc:mysql://localhost/Moonstone","root","");
        st=con.createStatement();
      String Query = "Select cID, Count(cID) From Secretary Where cID="+key+" Group By cID ORDER BY cID DESC LIMIT 1";
      rs = st.executeQuery(Query);
      while(rs.next()){
     //  JOptionPane.showMessageDialog(this,""+Votes);
       WinnerID2=rs.getInt(1);
      }
      
    }catch(Exception e){
    JOptionPane.showMessageDialog(this,e);
    }
}
     private void GetVote2(){
     
    
     try{    
        con=DriverManager.getConnection("jdbc:mysql://localhost/Moonstone","root","");
        st=con.createStatement();
  String Query = "Select Count(cID) From Secretary Where cID="+WinnerID2;
      rs = st.executeQuery(Query);
      while(rs.next()){
      // JOptionPane.showMessageDialog(this,""+Votes));
       Votes2=rs.getInt(1);
       Count2.setText(Votes2+ " Votes");
      }
      
    }catch(Exception e){
    JOptionPane.showMessageDialog(this,e);
    }
    }
  
     
     private void SecPhoto(){
    
    String query ="Select photo from candidate where cID="+key;
    Statement st;
    ResultSet rs;
    try{
     con=DriverManager.getConnection("jdbc:mysql://localhost/Moonstone","root","");
    st=con.createStatement();
    rs=st.executeQuery(query);
    if(rs.next()){
    
    candidatephoto2.setIcon(ResizePhoto(null,rs.getBytes("Photo")));
    }
    
    }catch (Exception e){
    
    
    }
    }
    
    private void SecMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SecMouseClicked
        // TODO add your handling code here:
        
         DefaultTableModel model= (DefaultTableModel) Sec.getModel();
        int MyIndex = Sec.getSelectedRow();
        key = Integer.valueOf(model.getValueAt(MyIndex, 0).toString());
         Name3.setText(model.getValueAt(MyIndex, 1).toString());
        Count2.setText(model.getValueAt(MyIndex, 2).toString());
      
        GetVote2();
        GetWinner2();
        SecPhoto();
    }//GEN-LAST:event_SecMouseClicked
private void DisplayTreasurer(){
    
    try{
     con=DriverManager.getConnection("jdbc:mysql://localhost/Moonstone","root","");
     st=con.createStatement();
     rs=st.executeQuery(" Select cID,Name,Photo from candidate where Position = 'Treasurer'");
   Treasurer.setModel(DbUtils.resultSetToTableModel(rs));
     
    }catch(Exception e){
    
    
    }
    }
   int WinnerID3,Votes3;
   private void GetWinner3(){
    
    
    try{    
        con=DriverManager.getConnection("jdbc:mysql://localhost/Moonstone","root","");
        st=con.createStatement();
      String Query = "Select cID, Count(cID) From Treasurer Where cID="+key+" Group By cID ORDER BY cID DESC LIMIT 1";
      rs = st.executeQuery(Query);
      while(rs.next()){
     //  JOptionPane.showMessageDialog(this,""+Votes);
       WinnerID3=rs.getInt(1);
      }
      
    }catch(Exception e){
    JOptionPane.showMessageDialog(this,e);
    }
}
     private void GetVote3(){
     
    
     try{    
        con=DriverManager.getConnection("jdbc:mysql://localhost/Moonstone","root","");
        st=con.createStatement();
  String Query = "Select Count(cID) From Treasurer Where cID="+WinnerID3;
      rs = st.executeQuery(Query);
      while(rs.next()){
      // JOptionPane.showMessageDialog(this,""+Votes));
       Votes3=rs.getInt(1);
       Count3.setText(Votes3+ " Votes");
      }
      
    }catch(Exception e){
    JOptionPane.showMessageDialog(this,e);
    }
    }
  
     
     private void TreasurerPhoto(){
    
    String query ="Select photo from candidate where cID="+key;
    Statement st;
    ResultSet rs;
    try{
     con=DriverManager.getConnection("jdbc:mysql://localhost/Moonstone","root","");
    st=con.createStatement();
    rs=st.executeQuery(query);
    if(rs.next()){
    
    candidatephoto3.setIcon(ResizePhoto(null,rs.getBytes("Photo")));
    }
    
    }catch (Exception e){
    
    
    }
    }
    private void TreasurerMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TreasurerMouseClicked
        // TODO add your handling code here:
        
         DefaultTableModel model= (DefaultTableModel) Treasurer.getModel();
        int MyIndex = Treasurer.getSelectedRow();
        key = Integer.valueOf(model.getValueAt(MyIndex, 0).toString());
         Name4.setText(model.getValueAt(MyIndex, 1).toString());
        Count3.setText(model.getValueAt(MyIndex, 2).toString());
        GetVote3();
        TreasurerPhoto();
        GetWinner3();
    }//GEN-LAST:event_TreasurerMouseClicked
private void DisplayAuditor(){
    
    try{
     con=DriverManager.getConnection("jdbc:mysql://localhost/Moonstone","root","");
     st=con.createStatement();
     rs=st.executeQuery(" Select cID,Name,Photo from candidate where Position = 'Auditor'");
   Auditor.setModel(DbUtils.resultSetToTableModel(rs));
     
    }catch(Exception e){
    
    
    }
    }
   int WinnerID4,Votes4;
   private void GetWinner4(){
    
    
    try{    
        con=DriverManager.getConnection("jdbc:mysql://localhost/Moonstone","root","");
        st=con.createStatement();
      String Query = "Select cID, Count(cID) From Auditor Where cID="+key+" Group By cID ORDER BY cID DESC LIMIT 1";
      rs = st.executeQuery(Query);
      while(rs.next()){
     //  JOptionPane.showMessageDialog(this,""+Votes);
       WinnerID4=rs.getInt(1);
      }
      
    }catch(Exception e){
    JOptionPane.showMessageDialog(this,e);
    }
}
     private void GetVote4(){
     
    
     try{    
        con=DriverManager.getConnection("jdbc:mysql://localhost/Moonstone","root","");
        st=con.createStatement();
  String Query = "Select Count(cID) From Auditor Where cID="+WinnerID4;
      rs = st.executeQuery(Query);
      while(rs.next()){
      // JOptionPane.showMessageDialog(this,""+Votes));
       Votes4=rs.getInt(1);
       Count4.setText(Votes4+ " Votes");
      }
      
    }catch(Exception e){
    JOptionPane.showMessageDialog(this,e);
    }
    }
  
     
     private void AuditorPhoto(){
    
    String query ="Select photo from candidate where cID="+key;
    Statement st;
    ResultSet rs;
    try{
     con=DriverManager.getConnection("jdbc:mysql://localhost/Moonstone","root","");
    st=con.createStatement();
    rs=st.executeQuery(query);
    if(rs.next()){
    
    candidatephoto4.setIcon(ResizePhoto(null,rs.getBytes("Photo")));
    }
    
    }catch (Exception e){
    
    }
    }
    private void AuditorMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_AuditorMouseClicked
        // TODO add your handling code here:
         DefaultTableModel model= (DefaultTableModel) Auditor.getModel();
        int MyIndex = Auditor.getSelectedRow();
        key = Integer.valueOf(model.getValueAt(MyIndex, 0).toString());
         Name5.setText(model.getValueAt(MyIndex, 1).toString());
        Count4.setText(model.getValueAt(MyIndex, 2).toString());
        GetVote4();
        AuditorPhoto();
        GetWinner4();
    }//GEN-LAST:event_AuditorMouseClicked
private void DisplayPIO(){
    
    try{
     con=DriverManager.getConnection("jdbc:mysql://localhost/Moonstone","root","");
     st=con.createStatement();
     rs=st.executeQuery(" Select cID,Name,Photo from candidate where Position = 'P.I.O'");
   PIO.setModel(DbUtils.resultSetToTableModel(rs));
     
    }catch(Exception e){
    
    
    }
    }
   int WinnerID5,Votes5;
   private void GetWinner5(){
    
    
    try{    
        con=DriverManager.getConnection("jdbc:mysql://localhost/Moonstone","root","");
        st=con.createStatement();
      String Query = "Select cID, Count(cID) From pio Where cID="+key+" Group By cID ORDER BY cID DESC LIMIT 1";
      rs = st.executeQuery(Query);
      while(rs.next()){
     //  JOptionPane.showMessageDialog(this,""+Votes);
       WinnerID5=rs.getInt(1);
      }
      
    }catch(Exception e){
    JOptionPane.showMessageDialog(this,e);
    }
}
     private void   GetVote5(){
     
    
     try{    
        con=DriverManager.getConnection("jdbc:mysql://localhost/Moonstone","root","");
        st=con.createStatement();
  String Query = "Select Count(cID) From pio Where cID="+WinnerID5;
      rs = st.executeQuery(Query);
      while(rs.next()){
      // JOptionPane.showMessageDialog(this,""+Votes));
       Votes5=rs.getInt(1);
       Count5.setText(Votes5+ " Votes");
      }
      
    }catch(Exception e){
    JOptionPane.showMessageDialog(this,e);
    }
    }
  
     
     private void PIOPhoto(){
    
    String query ="Select photo from candidate where cID="+key;
    Statement st;
    ResultSet rs;
    try{
     con=DriverManager.getConnection("jdbc:mysql://localhost/Moonstone","root","");
    st=con.createStatement();
    rs=st.executeQuery(query);
    if(rs.next()){
    
    candidatephoto5.setIcon(ResizePhoto(null,rs.getBytes("Photo")));
    }
    
    }catch (Exception e){
    
    }
    }
    private void PIOMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PIOMouseClicked
        // TODO add your handling code here:
        DefaultTableModel model= (DefaultTableModel) PIO.getModel();
        int MyIndex = PIO.getSelectedRow();
        key = Integer.valueOf(model.getValueAt(MyIndex, 0).toString());
         Name6.setText(model.getValueAt(MyIndex, 1).toString());
        Count5.setText(model.getValueAt(MyIndex, 2).toString());
        GetVote5();
        PIOPhoto();
        GetWinner5();
        
    }//GEN-LAST:event_PIOMouseClicked
private void DisplayOfficer(){
    
    try{
     con=DriverManager.getConnection("jdbc:mysql://localhost/Moonstone","root","");
     st=con.createStatement();
     rs=st.executeQuery(" Select cID,Name,Photo from candidate where Position = 'Protocol Officer'");
   Officer.setModel(DbUtils.resultSetToTableModel(rs));
     
    }catch(Exception e){
    
    
    }
    }
   int WinnerID6,Votes6;
   private void GetWinner6(){
    
    
    try{    
        con=DriverManager.getConnection("jdbc:mysql://localhost/Moonstone","root","");
        st=con.createStatement();
      String Query = "Select cID, Count(cID) From protocolofficer Where cID="+key+" Group By cID ORDER BY cID DESC LIMIT 1";
      rs = st.executeQuery(Query);
      while(rs.next()){
     //  JOptionPane.showMessageDialog(this,""+Votes);
       WinnerID6=rs.getInt(1);
      }
      
    }catch(Exception e){
    JOptionPane.showMessageDialog(this,e);
    }
}
     private void   GetVote6(){
     
    
     try{    
        con=DriverManager.getConnection("jdbc:mysql://localhost/Moonstone","root","");
        st=con.createStatement();
  String Query = "Select Count(cID) From protocolofficer Where cID="+WinnerID6;
      rs = st.executeQuery(Query);
      while(rs.next()){
      // JOptionPane.showMessageDialog(this,""+Votes));
       Votes6=rs.getInt(1);
       Count6.setText(Votes6+ " Votes");
      }
      
    }catch(Exception e){
    JOptionPane.showMessageDialog(this,e);
    }
    }
  
     
     private void candidatephoto6(){
    
    String query ="Select photo from candidate where cID="+key;
    Statement st;
    ResultSet rs;
    try{
     con=DriverManager.getConnection("jdbc:mysql://localhost/Moonstone","root","");
    st=con.createStatement();
    rs=st.executeQuery(query);
    if(rs.next()){
    
    candidatephoto6.setIcon(ResizePhoto(null,rs.getBytes("Photo")));
    }
    
    }catch (Exception e){
    
    }
    }
    private void OfficerMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_OfficerMouseClicked
        // TODO add your handling code here:
        
        DefaultTableModel model= (DefaultTableModel) Officer.getModel();
        int MyIndex = Officer.getSelectedRow();
        key = Integer.valueOf(model.getValueAt(MyIndex, 0).toString());
         Name7.setText(model.getValueAt(MyIndex, 1).toString());
        Count6.setText(model.getValueAt(MyIndex, 2).toString());
        GetVote6();
        candidatephoto6();
        GetWinner6();
    }//GEN-LAST:event_OfficerMouseClicked


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable Auditor;
    private javax.swing.JLabel Count;
    private javax.swing.JLabel Count1;
    private javax.swing.JLabel Count2;
    private javax.swing.JLabel Count3;
    private javax.swing.JLabel Count4;
    private javax.swing.JLabel Count5;
    private javax.swing.JLabel Count6;
    private javax.swing.JLabel Counts;
    private javax.swing.JLabel Counts1;
    private javax.swing.JLabel Counts2;
    private javax.swing.JLabel Counts3;
    private javax.swing.JLabel Counts4;
    private javax.swing.JLabel Counts5;
    private javax.swing.JLabel Counts6;
    private javax.swing.JLabel Name;
    private javax.swing.JLabel Name2;
    private javax.swing.JLabel Name3;
    private javax.swing.JLabel Name4;
    private javax.swing.JLabel Name5;
    private javax.swing.JLabel Name6;
    private javax.swing.JLabel Name7;
    private javax.swing.JTable Officer;
    private javax.swing.JTable PIO;
    private javax.swing.JTable Pres;
    private javax.swing.JLabel President;
    private javax.swing.JLabel President1;
    private javax.swing.JLabel President2;
    private javax.swing.JLabel President3;
    private javax.swing.JLabel President4;
    private javax.swing.JLabel President5;
    private javax.swing.JLabel President6;
    private javax.swing.JTable Sec;
    private javax.swing.JTable Treasurer;
    private javax.swing.JTable VicePres;
    private javax.swing.JLabel candidatephoto;
    private javax.swing.JLabel candidatephoto1;
    private javax.swing.JLabel candidatephoto2;
    private javax.swing.JLabel candidatephoto3;
    private javax.swing.JLabel candidatephoto4;
    private javax.swing.JLabel candidatephoto5;
    private javax.swing.JLabel candidatephoto6;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JSeparator jSeparator5;
    private javax.swing.JSeparator jSeparator6;
    private javax.swing.JSeparator jSeparator7;
    private javax.swing.JSeparator jSeparator8;
    private javax.swing.JSeparator jSeparator9;
    // End of variables declaration//GEN-END:variables
}
