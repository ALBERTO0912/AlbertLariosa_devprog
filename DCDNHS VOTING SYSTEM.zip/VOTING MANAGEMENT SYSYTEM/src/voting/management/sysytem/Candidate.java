/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JInternalFrame.java to edit this template
 */
package voting.management.sysytem;

import java.awt.Color;
import java.awt.Image;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.plaf.basic.BasicInternalFrameUI;
import javax.swing.table.DefaultTableModel;
import net.proteanit.sql.DbUtils;

/**
 *
 * @author User
 */
public class Candidate extends javax.swing.JInternalFrame {

    /**
     * Creates new form Candidate
     */
    public Candidate() {
        initComponents();
           FetchPhoto();
            DisplayCand();
            this.setBorder(javax.swing.BorderFactory.createEmptyBorder(0,0,0,0));
        BasicInternalFrameUI ui=(BasicInternalFrameUI)this.getUI();
        ui.setNorthPane(null);
        
    }

     Connection con= null;
PreparedStatement pst= null;
ResultSet rs = null;
Statement st = null;


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        kButton3 = new com.k33ptoo.components.KButton();
        cbyearlevel = new javax.swing.JComboBox<>();
        jLabel2 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        cbSection = new javax.swing.JComboBox<>();
        jLabel9 = new javax.swing.JLabel();
        Age = new javax.swing.JTextField();
        kButton1 = new com.k33ptoo.components.KButton();
        jLabel6 = new javax.swing.JLabel();
        kButton4 = new com.k33ptoo.components.KButton();
        cbGender = new javax.swing.JComboBox<>();
        kButton2 = new com.k33ptoo.components.KButton();
        candidatephoto = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        candidatetable = new javax.swing.JTable();
        cbPosition = new javax.swing.JComboBox<>();
        Name = new javax.swing.JTextField();
        jButton5 = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();

        setBackground(new java.awt.Color(0, 0, 0));
        setPreferredSize(new java.awt.Dimension(1390, 750));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setPreferredSize(new java.awt.Dimension(1390, 750));

        jPanel2.setBackground(new java.awt.Color(0, 153, 153));
        jPanel2.setPreferredSize(new java.awt.Dimension(1390, 750));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("Section :");
        jPanel2.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(342, 178, -1, -1));

        kButton3.setText("Delete");
        kButton3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        kButton3.setkBorderRadius(60);
        kButton3.setkEndColor(new java.awt.Color(0, 0, 0));
        kButton3.setkHoverEndColor(new java.awt.Color(51, 255, 255));
        kButton3.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        kButton3.setkHoverStartColor(new java.awt.Color(0, 0, 0));
        kButton3.setkSelectedColor(new java.awt.Color(0, 153, 153));
        kButton3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                kButton3MouseClicked(evt);
            }
        });
        jPanel2.add(kButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 590, 141, -1));

        cbyearlevel.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        cbyearlevel.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "11", "12" }));
        cbyearlevel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cbyearlevelMouseClicked(evt);
            }
        });
        cbyearlevel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbyearlevelActionPerformed(evt);
            }
        });
        jPanel2.add(cbyearlevel, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 133, 136, -1));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Age:");
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(36, 136, -1, -1));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Position:");
        jPanel2.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(338, 93, -1, -1));

        cbSection.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        cbSection.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbSectionActionPerformed(evt);
            }
        });
        jPanel2.add(cbSection, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 175, 136, -1));

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("Yearlevel :");
        jPanel2.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(338, 136, -1, -1));

        Age.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        jPanel2.add(Age, new org.netbeans.lib.awtextra.AbsoluteConstraints(96, 133, 81, -1));

        kButton1.setText("Add");
        kButton1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        kButton1.setkBorderRadius(60);
        kButton1.setkEndColor(new java.awt.Color(0, 0, 0));
        kButton1.setkHoverEndColor(new java.awt.Color(51, 255, 255));
        kButton1.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        kButton1.setkHoverStartColor(new java.awt.Color(0, 0, 0));
        kButton1.setkSelectedColor(new java.awt.Color(0, 153, 153));
        kButton1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                kButton1MouseClicked(evt);
            }
        });
        kButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                kButton1ActionPerformed(evt);
            }
        });
        jPanel2.add(kButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 590, 141, -1));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Gender :");
        jPanel2.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(26, 172, -1, -1));

        kButton4.setText("Reset");
        kButton4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        kButton4.setkBorderRadius(60);
        kButton4.setkEndColor(new java.awt.Color(0, 0, 0));
        kButton4.setkHoverEndColor(new java.awt.Color(51, 255, 255));
        kButton4.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        kButton4.setkHoverStartColor(new java.awt.Color(0, 0, 0));
        kButton4.setkSelectedColor(new java.awt.Color(0, 153, 153));
        kButton4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                kButton4MouseClicked(evt);
            }
        });
        jPanel2.add(kButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 590, 141, -1));

        cbGender.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        cbGender.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Male", "Female" }));
        jPanel2.add(cbGender, new org.netbeans.lib.awtextra.AbsoluteConstraints(96, 169, 88, -1));

        kButton2.setText("Update");
        kButton2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        kButton2.setkBackGroundColor(new java.awt.Color(0, 153, 153));
        kButton2.setkBorderRadius(60);
        kButton2.setkEndColor(new java.awt.Color(0, 0, 0));
        kButton2.setkHoverEndColor(new java.awt.Color(51, 255, 255));
        kButton2.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        kButton2.setkHoverStartColor(new java.awt.Color(0, 0, 0));
        kButton2.setkSelectedColor(new java.awt.Color(0, 153, 153));
        kButton2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                kButton2MouseClicked(evt);
            }
        });
        jPanel2.add(kButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 590, 141, -1));

        candidatephoto.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        candidatephoto.setForeground(new java.awt.Color(255, 255, 255));
        candidatephoto.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        candidatephoto.setText("Photo");
        candidatephoto.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 3, 0, new java.awt.Color(0, 204, 204)));
        jPanel2.add(candidatephoto, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 20, 310, 210));

        candidatetable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        candidatetable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                candidatetableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(candidatetable);

        jPanel2.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(26, 249, 1063, 309));

        cbPosition.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        cbPosition.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "President", "Vice-President", "Secretary", "Treasurer", "Auditor", "P.I.O", "Protocol Officer" }));
        jPanel2.add(cbPosition, new org.netbeans.lib.awtextra.AbsoluteConstraints(399, 90, 157, -1));

        Name.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        jPanel2.add(Name, new org.netbeans.lib.awtextra.AbsoluteConstraints(88, 90, 242, 25));

        jButton5.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        jButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pos/pro/img/search x30.png"))); // NOI18N
        jButton5.setText("Browser");
        jButton5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton5MouseClicked(evt);
            }
        });
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(950, 200, -1, -1));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Name :");
        jPanel2.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 93, -1, -1));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 1372, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, 708, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 1372, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 708, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
 String imgpath=null;
 
 private ImageIcon ResizePhoto(String ImagePath, byte[] pic)
 {
 
 
     ImageIcon MyImage = null;
     
     if(ImagePath != null)
     {
 
     MyImage = new ImageIcon(ImagePath);
     } else
     
     {
         MyImage =  new ImageIcon(pic);
         }
 Image img = MyImage.getImage();
 Image newimg= img.getScaledInstance(candidatephoto.getWidth(), candidatephoto.getHeight(),Image.SCALE_SMOOTH);
 ImageIcon image=new ImageIcon(newimg);
         return image;
 }
    private void jButton5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton5MouseClicked
        // TODO add your handling code here:
        JFileChooser chooser = new JFileChooser();
        chooser.setCurrentDirectory(new File (System.getProperty("user.home")));
        FileNameExtensionFilter filter= new FileNameExtensionFilter("*.Images","jpg,","gif","png");
        chooser.addChoosableFileFilter(filter);
        int result=chooser.showSaveDialog(null);
        if(result==JFileChooser.APPROVE_OPTION){

            File selectedFile = chooser.getSelectedFile();
            String path = selectedFile.getAbsolutePath();
            candidatephoto.setIcon(ResizePhoto(path,null));
            imgpath = path;
        }
    }//GEN-LAST:event_jButton5MouseClicked

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton5ActionPerformed

    private void cbSectionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbSectionActionPerformed

    }//GEN-LAST:event_cbSectionActionPerformed

    private void cbyearlevelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cbyearlevelMouseClicked
        // TODO add your handling code here:
        if(cbyearlevel.getSelectedItem().equals("11")){
        cbSection.removeAllItems();
         cbSection.addItem("BELL");
        cbSection.setSelectedItem(null);
        }else if(cbyearlevel.getSelectedItem().equals("12")){
        cbSection.removeAllItems();
        cbSection.addItem("MOONSTONE");
        cbSection.setSelectedItem(null);
        }
    }//GEN-LAST:event_cbyearlevelMouseClicked

    private void cbyearlevelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbyearlevelActionPerformed
        if(cbyearlevel.getSelectedItem().equals("11")){
            cbSection.removeAllItems();
            cbSection.addItem("BELL");
            cbSection.setSelectedItem(null);
        }else if(cbyearlevel.getSelectedItem().equals("12")){
            cbSection.removeAllItems();
            cbSection.addItem("MOONSTONE");
            cbSection.setSelectedItem(null);
        }
    }//GEN-LAST:event_cbyearlevelActionPerformed
private void FetchPhoto(){
    
    String query ="Select Photo from candidate where cID="+key;
    Statement st;
    ResultSet rs;
    try{
     con=DriverManager.getConnection("jdbc:mysql://localhost/Moonstone","root","");
    st=con.createStatement();
    rs=st.executeQuery(query);
    if(rs.next()){
    
    candidatephoto.setIcon(ResizePhoto(null,rs.getBytes("Photo")));
    
    }
    
    }catch (Exception e){
    
    
    }
    }
    
    
    
    
    int key = -1;
    private void candidatetableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_candidatetableMouseClicked
        // TODO add your handling code here:
        DefaultTableModel model= (DefaultTableModel) candidatetable.getModel();
        int MyIndex = candidatetable.getSelectedRow();
        key = Integer.valueOf(model.getValueAt(MyIndex, 0).toString());
        Name.setText(model.getValueAt(MyIndex, 1).toString());
        Age.setText(model.getValueAt(MyIndex, 2).toString());
        cbGender.setSelectedItem(model.getValueAt(MyIndex, 3).toString());
        cbyearlevel.setSelectedItem(model.getValueAt(MyIndex, 4).toString());
        cbSection.setSelectedItem(model.getValueAt(MyIndex, 5).toString());
        cbPosition.setSelectedItem(model.getValueAt(MyIndex, 6).toString());
        FetchPhoto();
    }//GEN-LAST:event_candidatetableMouseClicked
 private void DisplayCand(){
    
    try{
     con=DriverManager.getConnection("jdbc:mysql://localhost/Moonstone","root","");
     st=con.createStatement();
     rs=st.executeQuery("Select * from candidate");
   candidatetable.setModel(DbUtils.resultSetToTableModel(rs));
     
    }catch(Exception e){
    
    
    }
    }
 int cID;
    Statement st1 = null;
    ResultSet rs1= null;
  private void CandCount(){
        
try{
    
    st1 = con.createStatement();
    rs1 =  st1.executeQuery("Select Max(cID) From candidate");
    rs1.next();
    cID = rs1.getInt(1)+ 1;
    }catch(Exception ex){
            
            }


}
    private void kButton1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kButton1MouseClicked
        // TODO add your handling code here:
         if (Age.getText().isEmpty() || Name.getText().isEmpty() ){
            JOptionPane.showMessageDialog(this, "Missing Information");

        }else{
            try {
                CandCount();
                con=DriverManager.getConnection("jdbc:mysql://localhost/Moonstone","root","");
                PreparedStatement add=con.prepareStatement("Insert into candidate values(?,?,?,?,?,?,?,?)");
                InputStream img= new FileInputStream(imgpath);
                add.setInt(1, cID);
                add.setString(2, Name.getText());
                add.setInt(3, Integer.valueOf(Age.getText()));
                add.setString(4, cbGender.getSelectedItem().toString());
                add.setInt(5,Integer.valueOf(cbyearlevel.getSelectedItem().toString()));
                  add.setString(6, cbSection.getSelectedItem().toString());
                   add.setString(7, cbPosition.getSelectedItem().toString());
                add.setBlob(8, img);
               
                int row=add.executeUpdate();
                JOptionPane.showMessageDialog(this, "Candidate Registered");
                con.close();
                DisplayCand();

            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, ex);
            }

        }
    }//GEN-LAST:event_kButton1MouseClicked

    private void kButton2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kButton2MouseClicked
        // TODO add your handling code here:
          if(key== -1 || Name.getText().toString().isEmpty() || Age.getText().toString().isEmpty() || 
                cbGender.getSelectedIndex()==1 || cbyearlevel.getSelectedIndex()==-1 || cbSection.getSelectedIndex()==-1){

        }else if (imgpath != null)
        {
            try{
                InputStream  img= new FileInputStream(imgpath);
                con=DriverManager.getConnection("jdbc:mysql://localhost/Moonstone","root","");
                String Query = "Update candidate set Name=?,Age = ? ,Gender=?,YearLevel=?,Section=?,Position=?, Photo=?  where cID=?";
                PreparedStatement UpdateQuery = con.prepareStatement(Query);
                UpdateQuery.setString (1,Name.getText());
                UpdateQuery.setInt (2,Integer.valueOf(Age.getText().toString()));
                UpdateQuery.setString (3,cbGender.getSelectedItem().toString());
                  UpdateQuery.setString (4,cbyearlevel.getSelectedItem().toString());
                   UpdateQuery.setString (5,cbSection.getSelectedItem().toString());
                    UpdateQuery.setString (6,cbPosition.getSelectedItem().toString());
                UpdateQuery.setBlob (7,img);
                UpdateQuery.setInt (8,key);
                if(UpdateQuery.executeUpdate() == 1) {

                    JOptionPane.showMessageDialog(this, "Candidate Updated Succesfully");
                    DisplayCand();
                }else{
                    JOptionPane.showMessageDialog(this, "Missing Information");
                }

            }catch(Exception e){
                JOptionPane.showMessageDialog(this, e);
            }

        }else{
            JOptionPane.showMessageDialog(this, "Select Photo");
            candidatephoto.setIcon(null);
            candidatephoto.setText("");
        }
        imgpath = null;

    }//GEN-LAST:event_kButton2MouseClicked

    private void kButton3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kButton3MouseClicked
        // TODO add your handling code here:
          if(key== -1){
            JOptionPane.showMessageDialog(this, "Select The Candidate To Be  Deleted");
        }else
        {
            try{

                con=DriverManager.getConnection("jdbc:mysql://localhost/Moonstone","root","");
                String Query = "Delete From candidate where cID = "+key;
                Statement del = con.createStatement();
                del.executeUpdate(Query);
                JOptionPane.showMessageDialog(this, "candidate Deleted Succesfully");
                DisplayCand();
            }catch(Exception e){
                JOptionPane.showMessageDialog(this, e);
            }

        }
    }//GEN-LAST:event_kButton3MouseClicked

    private void kButton4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kButton4MouseClicked
        // TODO add your handling code here:
           Name.setText("");
        Age.setText("");
        cbGender.setSelectedItem("");
        cbPosition.setSelectedItem("");
        cbyearlevel.setSelectedItem("");
        cbSection.setSelectedItem("");
         candidatephoto.setIcon(null);
         
    }//GEN-LAST:event_kButton4MouseClicked

    private void kButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_kButton1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_kButton1ActionPerformed

           
       
        
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField Age;
    private javax.swing.JTextField Name;
    private javax.swing.JLabel candidatephoto;
    private javax.swing.JTable candidatetable;
    private javax.swing.JComboBox<String> cbGender;
    private javax.swing.JComboBox<String> cbPosition;
    private javax.swing.JComboBox<String> cbSection;
    private javax.swing.JComboBox<String> cbyearlevel;
    private javax.swing.JButton jButton5;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private com.k33ptoo.components.KButton kButton1;
    private com.k33ptoo.components.KButton kButton2;
    private com.k33ptoo.components.KButton kButton3;
    private com.k33ptoo.components.KButton kButton4;
    // End of variables declaration//GEN-END:variables
}
