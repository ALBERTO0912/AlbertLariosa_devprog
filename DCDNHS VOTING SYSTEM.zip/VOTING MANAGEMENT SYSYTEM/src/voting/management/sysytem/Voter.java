/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JInternalFrame.java to edit this template
 */
package voting.management.sysytem;

import java.awt.print.PrinterException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.plaf.basic.BasicInternalFrameUI;
import javax.swing.table.DefaultTableModel;
import net.proteanit.sql.DbUtils;

/**
 *
 * @author User
 */
public class Voter extends javax.swing.JInternalFrame {

    /**
     * Creates new form Voter
     */
    public Voter() {
        initComponents();
         DisplayVoters();
           this.setBorder(javax.swing.BorderFactory.createEmptyBorder(0,0,0,0));
        BasicInternalFrameUI ui=(BasicInternalFrameUI)this.getUI();
        ui.setNorthPane(null);
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        Age = new javax.swing.JTextField();
        kButton1 = new com.k33ptoo.components.KButton();
        kButton3 = new com.k33ptoo.components.KButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        VoterTable = new javax.swing.JTable();
        jLabel6 = new javax.swing.JLabel();
        kButton5 = new com.k33ptoo.components.KButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        Name = new javax.swing.JTextField();
        vcbGender = new javax.swing.JComboBox<>();
        Pass = new javax.swing.JTextField();
        Input = new com.k33ptoo.components.KButton();
        jLabel7 = new javax.swing.JLabel();
        Delete = new com.k33ptoo.components.KButton();
        jLabel3 = new javax.swing.JLabel();
        Section = new javax.swing.JTextField();
        Print = new com.k33ptoo.components.KButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtReciept = new javax.swing.JTextArea();
        kButton6 = new com.k33ptoo.components.KButton();
        VoterID = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();

        setPreferredSize(new java.awt.Dimension(1130, 760));

        jPanel1.setBackground(new java.awt.Color(0, 153, 153));
        jPanel1.setPreferredSize(new java.awt.Dimension(1390, 750));
        jPanel1.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                jPanel1AncestorAdded(evt);
            }
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Age.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jPanel1.add(Age, new org.netbeans.lib.awtextra.AbsoluteConstraints(104, 121, 81, -1));

        kButton1.setText("Update");
        kButton1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        kButton1.setkBorderRadius(60);
        kButton1.setkEndColor(new java.awt.Color(0, 0, 0));
        kButton1.setkHoverEndColor(new java.awt.Color(51, 255, 255));
        kButton1.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        kButton1.setkHoverStartColor(new java.awt.Color(0, 0, 0));
        kButton1.setkSelectedColor(new java.awt.Color(0, 153, 153));
        kButton1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                kButton1MouseClicked(evt);
            }
        });
        jPanel1.add(kButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 590, 152, -1));

        kButton3.setText("Delete");
        kButton3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        kButton3.setkBorderRadius(60);
        kButton3.setkEndColor(new java.awt.Color(0, 0, 0));
        kButton3.setkHoverEndColor(new java.awt.Color(51, 255, 255));
        kButton3.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        kButton3.setkHoverStartColor(new java.awt.Color(0, 0, 0));
        kButton3.setkSelectedColor(new java.awt.Color(0, 153, 153));
        kButton3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                kButton3MouseClicked(evt);
            }
        });
        jPanel1.add(kButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(940, 580, 152, -1));

        VoterTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        VoterTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                VoterTableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(VoterTable);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(471, 19, 622, 184));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Gender :");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 79, -1, -1));

        kButton5.setText("Add");
        kButton5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        kButton5.setkBorderRadius(60);
        kButton5.setkEndColor(new java.awt.Color(0, 0, 0));
        kButton5.setkHoverEndColor(new java.awt.Color(51, 255, 255));
        kButton5.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        kButton5.setkHoverStartColor(new java.awt.Color(0, 0, 0));
        kButton5.setkSelectedColor(new java.awt.Color(0, 153, 153));
        kButton5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                kButton5MouseClicked(evt);
            }
        });
        jPanel1.add(kButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(58, 586, 152, -1));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Voter ID :");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 260, -1, 40));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Age:");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(22, 117, -1, -1));

        Name.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jPanel1.add(Name, new org.netbeans.lib.awtextra.AbsoluteConstraints(104, 49, 272, -1));

        vcbGender.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        vcbGender.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Male", "Female" }));
        jPanel1.add(vcbGender, new org.netbeans.lib.awtextra.AbsoluteConstraints(104, 83, 116, -1));
        jPanel1.add(Pass, new org.netbeans.lib.awtextra.AbsoluteConstraints(109, 181, 255, -1));

        Input.setText("Input to Print");
        Input.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        Input.setkBorderRadius(60);
        Input.setkEndColor(new java.awt.Color(0, 0, 0));
        Input.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        Input.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                InputActionPerformed(evt);
            }
        });
        jPanel1.add(Input, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 310, 140, 26));

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Password:");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 177, -1, -1));

        Delete.setText("Reset");
        Delete.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        Delete.setkBorderRadius(60);
        Delete.setkEndColor(new java.awt.Color(0, 0, 0));
        Delete.setkHoverEndColor(new java.awt.Color(51, 255, 255));
        Delete.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        Delete.setkHoverStartColor(new java.awt.Color(0, 0, 0));
        Delete.setkSelectedColor(new java.awt.Color(0, 153, 153));
        Delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeleteActionPerformed(evt);
            }
        });
        jPanel1.add(Delete, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 590, 152, -1));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Section: ");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(22, 149, -1, -1));

        Section.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jPanel1.add(Section, new org.netbeans.lib.awtextra.AbsoluteConstraints(121, 153, 262, -1));

        Print.setText("Print");
        Print.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        Print.setkBorderRadius(60);
        Print.setkEndColor(new java.awt.Color(0, 0, 0));
        Print.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        Print.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PrintActionPerformed(evt);
            }
        });
        jPanel1.add(Print, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 360, 91, 26));

        txtReciept.setColumns(20);
        txtReciept.setRows(5);
        jScrollPane2.setViewportView(txtReciept);

        jPanel1.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 220, 620, 307));

        kButton6.setText("Search");
        kButton6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        kButton6.setkBorderRadius(60);
        kButton6.setkEndColor(new java.awt.Color(0, 0, 0));
        kButton6.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        kButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                kButton6ActionPerformed(evt);
            }
        });
        jPanel1.add(kButton6, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 270, 77, 26));
        jPanel1.add(VoterID, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 270, 150, -1));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Name :");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 45, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 1129, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 724, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
 int key =  -1;
    private void VoterTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_VoterTableMouseClicked
        // TODO add your handling code here:
        DefaultTableModel model= (DefaultTableModel) VoterTable.getModel();
        int MyIndex = VoterTable.getSelectedRow();
        key = Integer.valueOf(model.getValueAt(MyIndex, 0).toString());
        Name.setText(model.getValueAt(MyIndex, 1).toString());
         Age.setText(model.getValueAt(MyIndex, 2).toString());
        vcbGender.setSelectedItem(model.getValueAt(MyIndex, 3).toString());
        Section.setText(model.getValueAt(MyIndex, 4).toString());
        Pass.setText(model.getValueAt(MyIndex, 5).toString());
         
    }//GEN-LAST:event_VoterTableMouseClicked
 Connection con= null;
PreparedStatement pst= null;
ResultSet rs = null;
Statement st = null;

private void DisplayVoters(){
    
    try{
     con=DriverManager.getConnection("jdbc:mysql://localhost/Moonstone","root","");
     st=con.createStatement();
     rs=st.executeQuery("Select * from voter");
 VoterTable.setModel(DbUtils.resultSetToTableModel(rs));
     
    }catch(Exception e){
    
    
    }
    }
   int ID;
    Statement st1 = null;
    ResultSet rs1= null;
    
   private void VoteCount(){
        
try{
    
    st1 = con.createStatement();
    rs1 =  st1.executeQuery("Select Max(vID) From voter");
    rs1.next();
    ID = rs1.getInt(1)+ 1;
    }catch(Exception ex){
            
            }


}
    private void kButton5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kButton5MouseClicked
        // TODO add your handling code here:
         if (Age.getText().isEmpty() || Name.getText().isEmpty() || vcbGender.getSelectedIndex()== -1){
            JOptionPane.showMessageDialog(this, "Missing Information");

        }else {
            try {
                VoteCount();
                con=DriverManager.getConnection("jdbc:mysql://localhost/Moonstone","root","");
                PreparedStatement add=con.prepareStatement(" INSERT INTO voter value(?,?,?,?,?,?)");
                add.setInt(1, ID);
                add.setString(2, Name.getText());
                add.setInt(3, Integer.valueOf(Age.getText()));
                 add.setString(4, vcbGender.getSelectedItem().toString());
                add.setString(5, Section.getText()); 
                add.setString(6, Pass.getText());
               

               
                int row=add.executeUpdate();
                JOptionPane.showMessageDialog(this, "Voter now Registered");
                con.close();
                DisplayVoters();

            
               
           
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, ex);
            }

        }
    }//GEN-LAST:event_kButton5MouseClicked

    private void kButton1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kButton1MouseClicked
        // TODO add your handling code here:
         if(key== -1 || Name.getText().toString().isEmpty() || Age.getText().toString().isEmpty() || vcbGender.getSelectedIndex()==-1 ){
            JOptionPane.showMessageDialog(this, "Missing Information");
        }else
        {
            try{

                con=DriverManager.getConnection("jdbc:mysql://localhost/Moonstone","root","");
                String Query = "Update voter set Name=?, Age = ? ,Gender=?,Section=? ,Password=? where vID=?";
                PreparedStatement UpdateQuery = con.prepareStatement(Query);
                UpdateQuery.setString (1,Name.getText());
                UpdateQuery.setInt (2,Integer.valueOf(Age.getText().toString()));
                UpdateQuery.setString (3,vcbGender.getSelectedItem().toString());
                UpdateQuery.setString (4,Section.getText());
                  UpdateQuery.setString (5,Pass.getText());
                UpdateQuery.setInt (6,key);
                UpdateQuery.executeUpdate();

                JOptionPane.showMessageDialog(this, "Voter Updated Succesfully");
                DisplayVoters();
            }catch(Exception e){
                JOptionPane.showMessageDialog(this, e);
            }

        }

    }//GEN-LAST:event_kButton1MouseClicked

    private void kButton3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kButton3MouseClicked
        // TODO add your handling code here:
         if(key== -1){
            JOptionPane.showMessageDialog(this, "Select The Voter To Be  Deleted");
        }else
        {
            try{

                con=DriverManager.getConnection("jdbc:mysql://localhost/Moonstone","root","");
                String Query = "Delete From voter where vID = "+key;
                Statement del = con.createStatement();
                del.executeUpdate(Query);
                JOptionPane.showMessageDialog(this, "Voter Deleted Succesfully");
                DisplayVoters();
            }catch(Exception e){
                JOptionPane.showMessageDialog(this, e);
            }

        }
    }//GEN-LAST:event_kButton3MouseClicked

    private void DeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeleteActionPerformed
        // TODO add your handling code here:
          Name.setText("");
        Age.setText("");
         Pass.setText("");
         vcbGender.setSelectedItem(null);
         Section.setText("");
         txtReciept.setText("");
         VoterID.setText("");
    }//GEN-LAST:event_DeleteActionPerformed

    private void PrintActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PrintActionPerformed
        try {
            // TODO add your handling code here:
            txtReciept.print();
           
                
        } catch (PrinterException ex) {
            Logger.getLogger(Voter.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_PrintActionPerformed

    private void jPanel1AncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_jPanel1AncestorAdded
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel1AncestorAdded

    private void InputActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_InputActionPerformed
        // TODO add your handling code here:
         txtReciept.append("\t\t STUDENT / VOTER'S RECORD \n\n" +

            "STUDENTS / VOTER'S ID NO:\t\t\t"+VoterID.getText()+
            "\n=====================================================================\n"+
            "Name:\t\t\t"+Name.getText()+ "\n\n"+
            "Age:\t\t\t"+Age.getText()+ "\n\n"+
            "Gender:\t\t\t"+vcbGender.getSelectedItem()+ "\n\n"+
            "Section:\t\t\t"+Section.getText()+ "\n\n"+
            "Password:\t\t\t"+Pass.getText() + "\n\n"+
           
           
                    
    "==================  VOTE WISELY!!! VOTE HONESTLY!!!! ================="
        );
    }//GEN-LAST:event_InputActionPerformed

    private void kButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_kButton6ActionPerformed
        try {      
            // TODO add your handling code here:
            
            // TODO add your handling code here:
            
            String ID = VoterID.getText();
            pst = con.prepareStatement("SELECT * FROM Voter WHERE vID=?");
            pst.setString(1,ID);
            rs=pst.executeQuery();
            
            
            if(ID.equals("")){
                JOptionPane.showMessageDialog(this,"ID must be null");
                VoterID.requestFocus();

            }else if(rs.next()==true){
                Name.setText(rs.getString(2));
                vcbGender.setSelectedItem(rs.getString(4));
                Age.setText(rs.getString(3));
                Section.setText(rs.getString(5));
                Pass.setText(rs.getString(6));
            }
        } catch (SQLException ex) {
            Logger.getLogger(Voter.class.getName()).log(Level.SEVERE, null, ex);
        }
            
            
            
            
            
       
    }//GEN-LAST:event_kButton6ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField Age;
    private com.k33ptoo.components.KButton Delete;
    private com.k33ptoo.components.KButton Input;
    private javax.swing.JTextField Name;
    private javax.swing.JTextField Pass;
    private com.k33ptoo.components.KButton Print;
    private javax.swing.JTextField Section;
    private javax.swing.JTextField VoterID;
    private javax.swing.JTable VoterTable;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private com.k33ptoo.components.KButton kButton1;
    private com.k33ptoo.components.KButton kButton3;
    private com.k33ptoo.components.KButton kButton5;
    private com.k33ptoo.components.KButton kButton6;
    private javax.swing.JTextArea txtReciept;
    private javax.swing.JComboBox<String> vcbGender;
    // End of variables declaration//GEN-END:variables
}
